#include <pcl/io/pcd_io.h>
#include <pcl/features/normal_3d.h>
#include <pcl/visualization/pcl_visualizer.h>

int main(int argc, char **argv) 
{
  pcl::PointCloud<pcl::PointXYZ>::Ptr in_cloud(new pcl::PointCloud<pcl::PointXYZ> ());
  // Load a cloud from file
  pcl::PointCloud<pcl::Normal>::Ptr cloud_normals (new pcl::PointCloud<pcl::Normal>); 
  if ( pcl::io::loadPCDFile( "office_scene.pcd", *in_cloud ) < 0)
  {
    std::cout << "Error loading model cloud." << std::endl;
    return (-1);
  }
  
  pcl::NormalEstimation<pcl::PointXYZ, pcl::Normal> ne;
  ne.setInputCloud (in_cloud);  
  pcl::search::KdTree<pcl::PointXYZ>::Ptr tree (new pcl::search::KdTree<pcl::PointXYZ> ()); 
  ne.setSearchMethod (tree); 
  // Use all neighbors in a sphere of radius 3cm 
  ne.setRadiusSearch (0.03); 
  ne.compute ( *cloud_normals ); 
  

  // Setup the visualizer and show the cloud
  boost::shared_ptr<pcl::visualization::PCLVisualizer> viewer (new pcl::visualization::PCLVisualizer ("3D Viewer"));
  viewer->setBackgroundColor (0, 0, 0);
  pcl::visualization::PointCloudColorHandlerCustom<pcl::PointXYZ> cloud_color(in_cloud, 0, 0, 255);
  viewer->addPointCloud<pcl::PointXYZ> ( in_cloud, cloud_color, "Input cloud" );
  viewer->setPointCloudRenderingProperties (pcl::visualization::PCL_VISUALIZER_POINT_SIZE, 1, "Input cloud");
  viewer->addPointCloudNormals<pcl::PointXYZ,pcl::Normal>(in_cloud, cloud_normals, 2 );
  viewer->initCameraParameters ();
  
  // Wait until the visualizer is closed
  while (!viewer->wasStopped ())
  {
    viewer->spinOnce ( 1 );
  }
  
  return 0;
}
