#include <opencv2/opencv.hpp>
#include <pcl/point_cloud.h>
#include <pcl/point_types.h>
#include <pcl/visualization/pcl_visualizer.h>

pcl::PointCloud< pcl::PointXYZRGB >::Ptr depth2PointCloud ( const cv::Mat &depth_img,
                                                            const cv::Mat &rgb_img,
                                                            const Eigen::Matrix3f &camera_matrix,
                                                            float min_depth = 0.01f, float max_depth = 10.0f )
{
  // Create a new cloud
  pcl::PointCloud<pcl::PointXYZRGB>::Ptr pc_ptr ( new pcl::PointCloud<pcl::PointXYZRGB> );
  pc_ptr->points.resize ( depth_img.total() );
  Eigen::Matrix4f t_mat;
  t_mat.setIdentity();
  t_mat.block<3, 3> ( 0, 0 ) = camera_matrix.inverse();

  int i_pt = 0;
  for ( int y = 0; y < depth_img.rows; y++ )
  {
    const float *depth = depth_img.ptr<float> ( y );
    const uchar *bgr = rgb_img.ptr<uchar> ( y );
    uchar r, g, b;
    for ( int x = 0; x < depth_img.cols; x++, depth++, bgr+=3 )
    {
      float d = *depth;
      if ( d >= min_depth && d <= max_depth )
      {
        Eigen::Vector4f point = t_mat*Eigen::Vector4f ( x*d,y*d,d,1.0 );

        b = bgr[0];
        g = bgr[1];
        r = bgr[2];

        uint32_t rgb = ( static_cast<uint32_t> ( r ) << 16 |
                         static_cast<uint32_t> ( g ) << 8 |
                         static_cast<uint32_t> ( b ) );

        pc_ptr->points[i_pt].x = point ( 0 );
        pc_ptr->points[i_pt].y = point ( 1 );
        pc_ptr->points[i_pt].z = point ( 2 );

        pc_ptr->points[i_pt++].rgb = *reinterpret_cast<float*> ( &rgb );
      }
    }
  }

  pc_ptr->points.resize ( i_pt );
  pc_ptr->width = ( int ) pc_ptr->points.size();
  pc_ptr->height = 1;

  return pc_ptr;
}

int main(int argc, char **argv) 
{
  // Default kinect scale parameter
  double depth_scale = 0.001;  

  // Default kinect intrinsic parameters  
  float fx = 512, fy = 512, 
        cx = 320, cy = 240;
        
  Eigen::Matrix3f camera_matrix;
  camera_matrix<< fx,   0.0f, cx,
                  0.0f, fy,   cy,
                  0.0f, 0.0f, 1.0f;
  
  cv::Mat rgb_img, depth_img;
  
  // Read the deph image
  cv::Mat input_depth = cv::imread("test_depth.png", cv::IMREAD_ANYDEPTH );
  // Scale the depth image
  input_depth.convertTo(depth_img, CV_32F, depth_scale );
  // Read the rgb image
  rgb_img = cv::imread("test_rgb.png", cv::IMREAD_COLOR);
  
  // Show both images
  cv::Mat show_depth;
  cv::normalize(depth_img, show_depth, 0, 255, cv::NORM_MINMAX, CV_8UC3);//cv::DataType<cv::Vec3b>::type);
  cv::imshow("depth", show_depth );
  cv::imshow("rgb", rgb_img );
  
  // Wait 10 seconds...
  cv::waitKey(10000);

  // Generate and visualize the point cloud
  pcl::PointCloud< pcl::PointXYZRGB >::Ptr cloud_ptr = 
    depth2PointCloud( depth_img, rgb_img, camera_matrix );

  pcl::visualization::PCLVisualizer::Ptr viewer ( new pcl::visualization::PCLVisualizer ("3D Viewer") );
  viewer->setBackgroundColor (0, 0, 0);
  pcl::visualization::PointCloudColorHandlerRGBField<pcl::PointXYZRGB> rgb(cloud_ptr);
  viewer->addPointCloud<pcl::PointXYZRGB> (cloud_ptr, rgb, "sample cloud");
  viewer->setPointCloudRenderingProperties (pcl::visualization::PCL_VISUALIZER_POINT_SIZE, 
                                            3, "sample cloud");
  viewer->addCoordinateSystem (1.0);
  viewer->initCameraParameters ();
  
  while (!viewer->wasStopped ())
  {
    viewer->spinOnce ( 1 );
  }
  
  return 0;
  
}
