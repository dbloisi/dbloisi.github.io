/* License: Apache 2.0. See LICENSE file in root directory.
   Copyright(c) 2015 Intel Corporation. All Rights Reserved. */

/* This file simply verifies that rs.h can be correctly included by a C compiler */
#include <librealsense/rs.h>
