place the folder face_visualizer_3d in your catkin workspace
e.g., in ~/catkin_ws/src

run
$ catkin_make

download face.bag
http://www.dis.uniroma1.it/~bloisi/didattica/RobotProgramming/face.bag

run in a terminal
$ roscore

run in a second terminal
$ rosrun face_visualizer_3d face_visualizer_3d_node ~/catkin_ws/src/face_visualizer_3d/haarcascades/

run in a third terminal
rosbag play face.bag 

