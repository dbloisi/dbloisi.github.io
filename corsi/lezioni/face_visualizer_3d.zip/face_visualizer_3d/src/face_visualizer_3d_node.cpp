/* Sapienza University of Rome 
 * 
 * Robot Programming
 * Section of Elective in Artificial Intelligence (Complementi di Intelligenza Artificiale)
 * Master Artificial Intelligence and Robotics (Laurea Magistrale in Intelligenza Artificiale e Robotica)
 * A.A. 2014/2015
 *
 * Image processing with OpenCV 
 *
 * Domenico D. Bloisi and Andrea Pennisi 
 *
 * bloisi@dis.uniroma1.it pennisi@dis.uniroma1.it
 *
 *
 * Face Visualizer 3D
 * written by Roberto Capobianco and Jacopo Serafin
 *
 * This code is provided without any warranty about its usability. It is for educational purposes and should be regarded as such.
 *
 */

#include <opencv2/opencv.hpp>
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/highgui/highgui.hpp>

#include <boost/thread/thread.hpp>
#include <pcl/visualization/pcl_visualizer.h>
//#include <pcl/visualization/cloud_viewer.h>

#include <message_filters/subscriber.h>
#include <message_filters/synchronizer.h>
#include <message_filters/sync_policies/approximate_time.h>
#include <sensor_msgs/Image.h>
#include <sensor_msgs/image_encodings.h>
#include <image_transport/image_transport.h>
#include <cv_bridge/cv_bridge.h>
#include <pcl_conversions/pcl_conversions.h>

using namespace sensor_msgs;
using namespace message_filters;

cv::CascadeClassifier frontal_face_cascade;
cv::CascadeClassifier profile_face_cascade;
cv::Mat grayImage;

pcl::visualization::PCLVisualizer* viewer;
//pcl::visualization::CloudViewer *viewer;

cv::Rect findFace(const cv::Mat& grayImage);
void extractFace3D(pcl::PointCloud<pcl::PointXYZRGB>::Ptr face_cloud, const cv::Mat& rgbImage, const cv::Mat& depthImage, const cv::Rect face);

void face_extraction_3d_callback(const ImageConstPtr& depthImage_, const ImageConstPtr& rgbImage_) {
  cv_bridge::CvImagePtr rgbImage = cv_bridge::toCvCopy(rgbImage_, sensor_msgs::image_encodings::BGR8);
  cv_bridge::CvImageConstPtr depthImage = cv_bridge::toCvShare(depthImage_, sensor_msgs::image_encodings::TYPE_32FC1);
  cv_bridge::CvImageConstPtr rawDepthImage = cv_bridge::toCvShare(depthImage_, sensor_msgs::image_encodings::TYPE_16UC1);

  // Convert to grayscale
  cv::cvtColor(rgbImage->image, grayImage, CV_BGR2GRAY);    
  // Apply Histogram Equalization
  cv::equalizeHist(grayImage, grayImage);

  // Find a face and displace it
  cv::Rect face = findFace(grayImage);

  if(face.width != 0 && face.height != 0) {
    // Convert from ROS to PCL
    pcl::PointCloud<pcl::PointXYZRGB>::Ptr face_cloud(new pcl::PointCloud<pcl::PointXYZRGB>);;
    extractFace3D(face_cloud, rgbImage->image, depthImage->image, face);
    pcl::visualization::PointCloudColorHandlerRGBField<pcl::PointXYZRGB> rgbHandler(face_cloud);
    viewer->removePointCloud("face cloud");
    viewer->addPointCloud<pcl::PointXYZRGB>(face_cloud, rgbHandler, "face cloud");
    viewer->setPointCloudRenderingProperties(pcl::visualization::PCL_VISUALIZER_POINT_SIZE, 3, "face cloud");
   
    //viewer->showCloud(face_cloud);
  }

  cv::rectangle(rgbImage->image, face, cv::Scalar(0, 255, 0));
  cv::imshow("rgb", rgbImage->image);
  cv::moveWindow("rgb", 0, 0);
  //cv::imshow("depth", rawDepthImage->image);
  //cv::moveWindow("depth", 640, 0);
  cv::waitKey(1);

  
}

int main(int argc, char** argv) {
  if(argc < 2) {
    std::cout << "Usage: rosrun face_visualizer_3d face_visualizer_3d_node path/to/haarcascades_folder" << std::endl;
    return 0;
  }
  std::string haarcascade_dir = std::string(argv[1]);
	
  std::string frontalFaceCascadeFilename = haarcascade_dir + "/haarcascade_frontalface_alt.xml";
  std::string profileFaceCascadeFilename = haarcascade_dir + "/haarcascade_profileface.xml";
  if(!frontal_face_cascade.load(frontalFaceCascadeFilename) || !profile_face_cascade.load(profileFaceCascadeFilename)) {
    std::cerr << "Error while loading HAAR cascades." << std::endl;
    return -1;
  }

  viewer = new pcl::visualization::PCLVisualizer("Face Viewer");
  //viewer = new pcl::visualization::CloudViewer("Face Viewer");
  
  viewer->setBackgroundColor(0.33f, 0.33f, 0.33f);
  viewer->initCameraParameters();
  viewer->setCameraPosition(0.0f, 0.0f, 0.0f,
  			    0.0f, 0.0f, 1.0f,
  			    0.0f, -1.0f, 0.0f);

  ros::init(argc, argv, "face_visualizer_3d_node");

  ros::NodeHandle nh;
  message_filters::Subscriber<Image> depth_sub(nh, "/camera/depth_registered/image_raw", 1);
  message_filters::Subscriber<Image> rgb_sub(nh, "/camera/rgb/image_rect_color", 1);

  typedef sync_policies::ApproximateTime<Image, Image> syncPolicy;
  Synchronizer<syncPolicy> sync(syncPolicy(10), depth_sub, rgb_sub);
  sync.registerCallback(boost::bind(&face_extraction_3d_callback, _1, _2));

  while(!viewer->wasStopped()) {
    ros::spinOnce();
    
    viewer->spinOnce();
  }
  delete(viewer);

  return 0;
}

cv::Rect findFace(const cv::Mat& grayImage) {
  // Detect frontal and side faces
  std::vector<cv::Rect> frontal_face_vector;
  std::vector<cv::Rect> profile_face_vector;
  std::vector<cv::Rect> face_vector;
  frontal_face_cascade.detectMultiScale(grayImage, frontal_face_vector, 1.4, 2, 0|CV_HAAR_SCALE_IMAGE, cv::Size(25, 25));
  profile_face_cascade.detectMultiScale(grayImage, profile_face_vector, 1.4, 2, 0|CV_HAAR_SCALE_IMAGE, cv::Size(25, 25));
  face_vector.insert(face_vector.end(), frontal_face_vector.begin(), frontal_face_vector.end());
  face_vector.insert(face_vector.end(), profile_face_vector.begin(), profile_face_vector.end());
		
  // Select the biggest face
  int max_area = 0;
  cv::Rect* face = new cv::Rect(0.0f, 0.0f, 0.0f, 0.0f);
  for(std::vector<cv::Rect>::iterator it = face_vector.begin(); it != face_vector.end(); it++) {
    if(std::max(max_area, it->width * it->height) != max_area) {
      face = &(*it);      
      max_area = it->width * it->height;
    }
  }

  return *face;
}

void extractFace3D(pcl::PointCloud<pcl::PointXYZRGB>::Ptr face_cloud, const cv::Mat& rgbImage, const cv::Mat& depthImage, const cv::Rect face) {
  float f = 525.0f;
  float cx = 319.5f;
  float cy = 239.5f;
  for(int r = face.y; r < face.y + face.width; r++) {
    for(int c = face.x; c < face.x + face.height; c++) {      
      float d = depthImage.at<float>(r, c);
      if(d != 0 && d < 2000.0f) {
	pcl::PointXYZRGB point;
	point.z = d / 1000.0f;
	point.x = (c - cx) * point.z / f; 
	point.y = (r - cy) * point.z / f;
	cv::Vec3b pixel = rgbImage.at<cv::Vec3b>(r, c);
	point.r = pixel[2];
	point.g = pixel[1];
	point.b = pixel[0];
	face_cloud->points.push_back(point);
      }
    }
  }
}
