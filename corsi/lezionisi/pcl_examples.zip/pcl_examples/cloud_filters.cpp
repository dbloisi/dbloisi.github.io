#include <pcl/io/pcd_io.h>
#include <pcl/filters/passthrough.h>
#include <pcl/filters/voxel_grid.h>
#include <pcl/visualization/pcl_visualizer.h>

int main(int argc, char **argv) 
{
  pcl::PointCloud<pcl::PointXYZ>::Ptr in_cloud(new pcl::PointCloud<pcl::PointXYZ> ()),
                                      cutted_cloud(new pcl::PointCloud<pcl::PointXYZ> ()),
                                      subsamp_cloud(new pcl::PointCloud<pcl::PointXYZ> ());
  
  // Load a cloud from file
  if (pcl::io::loadPCDFile (argv[1], *in_cloud) == -1)
  {
    cout << "Could not read file" << endl;
    return -1;
  }
  
  // Setup the visualizer and show the cloud
  boost::shared_ptr<pcl::visualization::PCLVisualizer> viewer (new pcl::visualization::PCLVisualizer ("3D Viewer"));
  viewer->setBackgroundColor (0, 0, 0);
  viewer->addPointCloud<pcl::PointXYZ> ( in_cloud, "Input cloud" );
  viewer->addCoordinateSystem (1.0);
  viewer->initCameraParameters ();
  
  // Wait until the visualizer is closed
  while (!viewer->wasStopped ())
  {
    viewer->spinOnce ( 1 );
  }
  
  // Filter out points outside a specified range in one dimension
  pcl::PassThrough<pcl::PointXYZ> pass_through;
  pass_through.setInputCloud (in_cloud);
  pass_through.setFilterLimits (0.0, 2.0);
  pass_through.setFilterFieldName ("y");
  // Get the new cloud
  pass_through.filter( *cutted_cloud );
  
  // Copy the filtered cloud into a new cloud colored in green
  pcl::visualization::PointCloudColorHandlerCustom<pcl::PointXYZ> cutted_color(cutted_cloud, 0, 255, 0);
  // Show the new cloud
  viewer->addPointCloud<pcl::PointXYZ> ( cutted_cloud, cutted_color, "Cutted cloud" );
  
  // Wait until the visualizer is closed
  viewer->resetStoppedFlag();
  while (!viewer->wasStopped ())
  {
    viewer->spinOnce ( 1 );
  }
  
  // Remove the original cloud from the visualizer
  viewer->removePointCloud("Input cloud");
  // Wait until the visualizer is closed
  viewer->resetStoppedFlag();
  while (!viewer->wasStopped ())
  {
    viewer->spinOnce ( 1 );
  }
  
  // Downsample the cloud
  pcl::VoxelGrid<pcl::PointXYZ> voxel_grid;
  voxel_grid.setInputCloud (cutted_cloud);
  // 10 cm resolution
  voxel_grid.setLeafSize (0.1, 0.1, 0.1);
  // Get the new cloud
  voxel_grid.filter ( *subsamp_cloud ) ;
  
  // Copy the downsampled cloud into a new cloud colored in red
  pcl::visualization::PointCloudColorHandlerCustom<pcl::PointXYZ> subsamp_color(subsamp_cloud, 255, 0, 0);
  // Show the new cloud
  viewer->addPointCloud<pcl::PointXYZ> ( subsamp_cloud, subsamp_color, "Voxelized cloud" );
  viewer->setPointCloudRenderingProperties (pcl::visualization::PCL_VISUALIZER_POINT_SIZE, 3, "Voxelized cloud");
  
  // Wait until the visualizer is closed
  viewer->resetStoppedFlag();
  while (!viewer->wasStopped ())
  {
    viewer->spinOnce ( 1 );
  }
  
  // Remove the filtered cloud from the visualizer
  viewer->removePointCloud("Cutted cloud");
  // Wait until the visualizer is closed
  viewer->resetStoppedFlag();
  while (!viewer->wasStopped ())
  {
    viewer->spinOnce ( 1 );
  }
  
  if ( pcl::io::savePCDFile( "res_cloud.pcd", *subsamp_cloud) < 0)
  {
    std::cout << "Error saving model cloud." << std::endl;
    return (-1);
  }
}
