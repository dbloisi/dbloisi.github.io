#include <pcl/io/pcd_io.h>
#include <pcl/point_types.h>
#include <pcl/registration/icp.h>

#include <iostream>
using std::cout;
using std::endl;

typedef pcl::PointXYZ PointType;
typedef pcl::PointCloud<PointType> Cloud;
typedef Cloud::ConstPtr CloudConstPtr;
typedef Cloud::Ptr CloudPtr;

int
main (int argc, char **argv)
{
  pcl::PointCloud<pcl::PointXYZ>::Ptr cloud1 (new pcl::PointCloud<pcl::PointXYZ>);
  if (pcl::io::loadPCDFile (argv[1], *cloud1) == -1)
  {
    cout << "Could not read file" << endl;
    return -1;
  }
  cout << "widh: " << cloud1->width << " height: " << cloud1->height << endl;

  pcl::PointCloud<pcl::PointXYZ>::Ptr cloud2 (new pcl::PointCloud<pcl::PointXYZ>);
  if (pcl::io::loadPCDFile (argv[2], *cloud2) == -1)
  {
    cout << "Could not read file" << endl;
    return -1;
  }
  cout << "widh: " << cloud2->width << " height: " << cloud2->height << endl;

  //pcl::GeneralizedIterativeClosestPoint<pcl::PointXYZ, pcl::PointXYZ> icp;
  pcl::IterativeClosestPoint<pcl::PointXYZ, pcl::PointXYZ> icp;
  icp.setInputCloud (cloud2);
  icp.setInputTarget (cloud1);
  // Set the maximum number of iterations (criterion 1)
  icp.setMaximumIterations(50);
  // Set the transformation epsilon (criterion 2)
  icp.setTransformationEpsilon(1e-8);
  // Set the euclidean distance difference epsilon (criterion 3)
  icp.setEuclideanFitnessEpsilon(1);
  // Perform the alignment
  pcl::PointCloud<pcl::PointXYZ>::Ptr cloud_source_registered(new pcl::PointCloud<pcl::PointXYZ>);
  icp.align(*cloud_source_registered);
  // Align cloud_source to cloud_source_registered
  Eigen::Matrix4f transformation = icp.getFinalTransformation();

  pcl::io::savePCDFile ("registered.pcd", *cloud_source_registered);
  std::cout << transformation << std::endl;

  return 0;
}
