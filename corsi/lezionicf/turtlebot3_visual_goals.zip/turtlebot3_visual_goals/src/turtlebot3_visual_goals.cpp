/* University of Verona
 * 
 * Laboratorio Ciberfisico
 * Robot Programming with ROS
 *
 * A.A. 2017/2018 
 *
 * Domenico D. Bloisi 
 *
 * domenico.bloisi@univr.it
 *
 *
 * turtlebot3_visual_goals
 * 
 *
 * This code is provided without any warranty about its usability.
 * It is for educational purposes and should be regarded as such.
 *
 */

#include <ros/ros.h>
#include <move_base_msgs/MoveBaseAction.h>
#include <actionlib/client/simple_action_client.h>

#include <opencv2/opencv.hpp>
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/highgui/highgui.hpp>

#include <boost/thread/thread.hpp>

#include <message_filters/subscriber.h>
#include <message_filters/synchronizer.h>
#include <message_filters/sync_policies/approximate_time.h>
#include <sensor_msgs/Image.h>
#include <sensor_msgs/image_encodings.h>
#include <image_transport/image_transport.h>
#include <cv_bridge/cv_bridge.h>


typedef actionlib::SimpleActionClient<move_base_msgs::MoveBaseAction> MoveBaseClient;

using namespace sensor_msgs;
using namespace message_filters;
using namespace cv;

bool goal_is_ready = false;
double goal_position_x = 0.0;

cv::Mat locateBall(const cv::Mat& rgbImage,
               const cv::Mat& depthImage);

cv::Mat getColorDepth(const cv::Mat& depthImage);

void camera_callback(const ImageConstPtr& depthImage_, const ImageConstPtr& rgbImage_) {
  cv_bridge::CvImagePtr rgbImage = cv_bridge::toCvCopy(rgbImage_, sensor_msgs::image_encodings::BGR8);
  cv_bridge::CvImagePtr depthImage = cv_bridge::toCvCopy(depthImage_, sensor_msgs::image_encodings::TYPE_32FC1);

  cv::Mat rgb = (rgbImage->image).clone();
  cv::Mat depth = (depthImage->image).clone();

  cv::Mat mask = locateBall(rgb, depth);

  cv::Mat rgb_gui(360, 640, CV_8UC3);
  cv::resize(rgb, rgb_gui, rgb_gui.size());
  cv::imshow("rgb", rgb_gui);

  cv::Mat depth_gui(360, 640, CV_32FC1);
  cv::resize(depth, depth_gui, depth_gui.size());

  cv::Mat colorDepth = getColorDepth(depth_gui);
  cv::imshow("depth", colorDepth);
  
  cv::Mat mask_gui(360, 640, CV_8UC1);
  cv::resize(mask, mask_gui, mask_gui.size());
  cv::imshow("mask", mask_gui);

  cv::waitKey(30);
}



int main(int argc, char** argv){
  ros::init(argc, argv, "turtlebot3_visual_goals");

  //tell the action client that we want to spin a thread by default
  MoveBaseClient ac("move_base", true);

  //wait for the action server to come up
  while(!ac.waitForServer(ros::Duration(5.0))){
    ROS_INFO("Waiting for the move_base action server to come up");
  }

  move_base_msgs::MoveBaseGoal goal;

  ros::NodeHandle nh;
  //!!!select the correct topic name for depth data
  message_filters::Subscriber<Image> depth_sub(nh, "/camera/depth/image_raw", 1);
  //!!!select the correct topic name for color data
  message_filters::Subscriber<Image> rgb_sub(nh, "/camera/rgb/image_raw", 1);

  cv::namedWindow("rgb");
  cv::namedWindow("depth");
  cv::namedWindow("mask");


  typedef sync_policies::ApproximateTime<Image, Image> syncPolicy;
  Synchronizer<syncPolicy> sync(syncPolicy(10), depth_sub, rgb_sub);
  sync.registerCallback(boost::bind(&camera_callback, _1, _2));

  bool run = true;

  while(run) {
    if(goal_is_ready) {

        //we'll send a goal to the robot to move 1 meter forward
        goal.target_pose.header.frame_id = "base_link";
        goal.target_pose.header.stamp = ros::Time::now();

        goal.target_pose.pose.position.x = goal_position_x - 0.2;
        goal.target_pose.pose.orientation.w = 1.0;

        ROS_INFO("Sending goal");
        ac.sendGoal(goal);

        ROS_INFO("Goal sent, waiting for results");
        ac.waitForResult();

        if(ac.getState() == actionlib::SimpleClientGoalState::SUCCEEDED)
            ROS_INFO("Hooray, the base moved 1 meter forward");
        else
            ROS_INFO("The base failed to move forward 1 meter for some reason");


    }

    ros::spinOnce();
  }
  

  return 0;
}


cv::Mat locateBall(const cv::Mat& rgbImage,
                const cv::Mat& depthImage)
{  
    cv::Mat mask(rgbImage.rows, rgbImage.cols, CV_8UC1);
    mask.setTo(cv::Scalar(0, 0, 0));
    
    for(int r = 0; r < mask.rows; r++) {
        for(int c = 0; c < mask.cols; c++) {       
            
            cv::Vec3b intensity = rgbImage.at<cv::Vec3b>(r, c);
	    uchar blue = intensity.val[0];
            uchar green = intensity.val[1];
            uchar red = intensity.val[2];
            
            if(red > 60 && green < red/2 && blue < green/2) {
                mask.at<uchar>(r,c) = 255;
            }           
            
        }

    }

    cv::Point centroid(0,0);
    std::vector < std::vector<Point> > contours;
    cv::findContours(mask, contours, RETR_LIST, CHAIN_APPROX_NONE);
    Moments moms;
    double area;
    for (size_t contourIdx = 0; contourIdx < contours.size(); ++contourIdx)
    {
        moms = moments(Mat(contours[contourIdx]));
        area = moms.m00;
        if (area > 100)
        {
            centroid = cv::Point (moms.m10/moms.m00 , moms.m01/moms.m00);
	    circle( mask, centroid, 6, Scalar(120), CV_FILLED );
        }
    }

    if(centroid.x != 0 && centroid.y != 0) {
        float d = depthImage.at<float>(centroid);
        if(d != 0.0 && d < 5.0) {
            ROS_INFO("GOAL IS READY d = %f", d);
            goal_is_ready = true;
            goal_position_x = d;
        }
    }

    return mask;
}


cv::Mat getColorDepth(const cv::Mat& depthImage) {

  cv::Mat colorMat(depthImage.rows, depthImage.cols, CV_8UC3);
  colorMat.setTo(cv::Scalar(0, 0, 0));

  for(int y = 0; y < depthImage.rows; y++) {
    for(int x = 0; x < depthImage.cols; x++) {      
      float d = depthImage.at<float>(y, x);
      if(d != 0 && d < 5000.0f) {
	if(d < 0.5f) {
          colorMat.at<cv::Vec3b>(y,x) = cv::Vec3b(0, 0, 191);
        }
	else if(d < 0.8f) {
          colorMat.at<cv::Vec3b>(y,x) = cv::Vec3b(0, 0, 255);
        }
        else if(d < 1.1f) {
          colorMat.at<cv::Vec3b>(y,x) = cv::Vec3b(0, 63, 255);
        }
        else if(d < 1.4f) {
          colorMat.at<cv::Vec3b>(y,x) = cv::Vec3b(0, 127, 255);
        }
        else if(d < 1.7f) {
          colorMat.at<cv::Vec3b>(y,x) = cv::Vec3b(0, 191, 255);
        }
        else if(d < 2.0f) {
          colorMat.at<cv::Vec3b>(y,x) = cv::Vec3b(0, 255, 255);
        }
        else if(d < 2.3f) {
          colorMat.at<cv::Vec3b>(y,x) = cv::Vec3b(63, 255, 191);
        }
        else if(d < 2.6f) {
          colorMat.at<cv::Vec3b>(y,x) = cv::Vec3b(127, 255, 127);
        }
        else if(d < 2.9f) {
          colorMat.at<cv::Vec3b>(y,x) = cv::Vec3b(191, 255, 63);
        }
        else if(d < 3.2f) {
          colorMat.at<cv::Vec3b>(y,x) = cv::Vec3b(255, 255, 0);
        }
        else if(d < 3.5f) {
          colorMat.at<cv::Vec3b>(y,x) = cv::Vec3b(255, 191, 0);
        }
        else if(d < 3.8f) {
          colorMat.at<cv::Vec3b>(y,x) = cv::Vec3b(255, 127, 0);
        }
        else if(d < 4.1f) {
          colorMat.at<cv::Vec3b>(y,x) = cv::Vec3b(255, 63, 0);
        }
        else if(d < 4.4f) {
          colorMat.at<cv::Vec3b>(y,x) = cv::Vec3b(255, 0, 0);
        }
        else if(d < 4.7f) {
          colorMat.at<cv::Vec3b>(y,x) = cv::Vec3b(191, 0, 0);
        }
        else {
          colorMat.at<cv::Vec3b>(y,x) = cv::Vec3b(143, 0, 0);
        }
      }
    }
  }
  return colorMat;

}

