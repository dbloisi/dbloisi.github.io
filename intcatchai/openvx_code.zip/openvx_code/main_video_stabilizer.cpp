/*
# Copyright (c) 2014-2016, NVIDIA CORPORATION. All rights reserved.
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions
# are met:
#  * Redistributions of source code must retain the above copyright
#    notice, this list of conditions and the following disclaimer.
#  * Redistributions in binary form must reproduce the above copyright
#    notice, this list of conditions and the following disclaimer in the
#    documentation and/or other materials provided with the distribution.
#  * Neither the name of NVIDIA CORPORATION nor the names of its
#    contributors may be used to endorse or promote products derived
#    from this software without specific prior written permission.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS ``AS IS'' AND ANY
# EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
# IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
# PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR
# CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
# EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
# PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
# PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
# OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
# (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
# OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#include <iostream>
#include <sstream>
#include <iomanip>
#include <string>
#include <memory>

#include <NVX/nvx.h>
#include <NVX/nvx_timer.hpp>

#include <NVXIO/Application.hpp>
#include <NVXIO/FrameSource.hpp>
#include <NVXIO/Render.hpp>
#include <NVXIO/SyncTimer.hpp>
#include <NVXIO/Utility.hpp>

#include "stabilizer.hpp"

#include <opencv2/opencv.hpp>
#include <NVX/nvx_opencv_interop.hpp>

#include "powermon.hpp"
#include "Timer.hpp"

class ReaderCV
{
public:
    nvxio::ContextGuard context;
    uint32_t width, height;
private:
    cv::VideoCapture cap;
    cv::Mat frame;
    uint64_t timeBetweenFrames; //ns
    int64_t remainingTime; //ns
    timer::Timer<timer::HOST> timerRead;
    vx_image img;
    
    int framesToSkip_;
	bool goRealTime_;
    
public:
    ReaderCV(std::string videoFilePath, int framesToSkip, bool goRealTime)
        :
          context(),
          cap(videoFilePath),
					framesToSkip_(framesToSkip),
					goRealTime_(goRealTime)
    {
        if(!cap.isOpened()) std::cerr << "Error opening video!" << std::endl;

        width  = static_cast<uint32_t>(cap.get(CV_CAP_PROP_FRAME_WIDTH));
        height = static_cast<uint32_t>(cap.get(CV_CAP_PROP_FRAME_HEIGHT));

        double fps = cap.get(CV_CAP_PROP_FPS);
        timeBetweenFrames = (framesToSkip + 1) * static_cast<uint64_t>(1000000000 / fps);//time in nanosecond
        remainingTime = 0;

        img = vxCreateImage(context, width, height, VX_DF_IMAGE_RGBX);
    }
    ~ReaderCV()
    {
        vxReleaseImage(&img);
    }

    int read(vx_image frame, Powermon* p)
    {
        timerRead.stop();
        int framesSkipped = 0;
        remainingTime += timerRead.durationNano();
        //advance of 1 timestep
        remainingTime -= timeBetweenFrames;
        
		if(goRealTime_)
		{
		    if(remainingTime < 0) //finished before, need to wait
		    {
		        std::this_thread::sleep_for(std::chrono::nanoseconds(-remainingTime));
		        //std::this_thread::sleep_for(std::chrono::milliseconds(100));
		        remainingTime = 0;
		        p->pauseCollection();
		    }
		    else //skip n timesteps (minus the one that i read)
		    {
				    p->pauseCollection();
		        while(remainingTime > timeBetweenFrames)
		        {
		            ++framesSkipped;
		            for(int i = framesToSkip_; i >= 0; --i) if(!cap.grab()) return -1;
		            remainingTime -= timeBetweenFrames;
		        }
		    }
		}
		
        vx_uint32 plane_index = 0;
        vx_rectangle_t rect = {
            0u, 0u,
            width, height
        };

        cv::Mat imgCV;
        bool res = true;
        for(int i = framesToSkip_ - 1; i >= 0; --i) res &= cap.grab();
        res &= cap.read(imgCV);

        if(res)
        {
            {
                nvx_cv::VXImageToCVMatMapper map(img, plane_index, &rect, VX_WRITE_ONLY, VX_MEMORY_TYPE_HOST);
                cv::Mat imgVX = map.getMat();
                cv::cvtColor(imgCV, imgVX, CV_BGR2RGBA);
            }
            nvxuCopyImage(context, img, frame);
            return framesSkipped;
        }
        else
            return -1;
    }

    void start()
    {
        timerRead.start();
    }
};
class ReaderVX
{
public:
    nvxio::ContextGuard context;
    uint32_t width, height;
private:
    std::unique_ptr<nvxio::FrameSource> videoSource;
    //vx_image img;

    uint64_t timeBetweenFrames; //ns
    int64_t remainingTime; //ns
    int framesToSkip_;
    timer::Timer<timer::HOST> timerRead;
	bool goRealTime_;
public:
    ReaderVX(std::string videoFilePath, int framesToSkip, bool goRealTime)
        :
          context(),
          videoSource(nvxio::createDefaultFrameSource(context, videoFilePath)),
          framesToSkip_(framesToSkip),
		  goRealTime_(goRealTime)
    {
        NVXIO_CHECK_REFERENCE((vx_reference) context);
        if (!videoSource || !videoSource->open())
        {
            std::cerr << "Error: Can't open source file: " << videoFilePath << std::endl;
            //return nvxio::Application::APP_EXIT_CODE_NO_RESOURCE;
        }

        if (videoSource->getSourceType() == nvxio::FrameSource::SINGLE_IMAGE_SOURCE)
        {
            std::cerr << "Error: Can't work on a single image." << std::endl;
            //return nvxio::Application::APP_EXIT_CODE_INVALID_FORMAT;
        }

        nvxio::FrameSource::Parameters sourceParams = videoSource->getConfiguration();
        //img = vxCreateImage(context, sourceParams.frameWidth, sourceParams.frameHeight, VX_DF_IMAGE_RGBX);
        width  = sourceParams.frameWidth;
        height = sourceParams.frameHeight;
        //std::cout << sourceParams.frameWidth << " x " << sourceParams.frameHeight << std::endl;
        //std::cout << width << " x " << height << std::endl;

        uint32_t fps = sourceParams.fps+1;//to get 60 fps
        timeBetweenFrames = (framesToSkip + 1) * static_cast<uint64_t>(1000000000 / static_cast<double>(fps));//time in nanosecond
        remainingTime = 0;
    }

    ~ReaderVX()
    {
        videoSource->close();
        //vxReleaseImage(&img);
    }
    int read(vx_image img, Powermon* p)
    {
        timerRead.stop();
        NVXIO_CHECK_REFERENCE((vx_reference) context);
        nvxio::FrameSource::FrameStatus frameStatus;

        int framesSkipped = 0;
        remainingTime += timerRead.durationNano();
        //advance of 1 timestep
        remainingTime -= timeBetweenFrames;
				
		if(goRealTime_)
		    if(remainingTime < 0) //finished before, need to wait
		    {
		        std::this_thread::sleep_for(std::chrono::nanoseconds(-remainingTime));
		        //std::this_thread::sleep_for(std::chrono::milliseconds(1000));
		        p->pauseCollection();	
		        remainingTime = 0;
		    }
		    else //skip n timesteps (minus the one that i read)
		    {
		    	p->pauseCollection();
		        while(remainingTime > timeBetweenFrames)
		        {
		            framesSkipped++;
									for(int i = framesToSkip_; i >= 0; --i)
									{
				          do
				          {
				          	frameStatus = videoSource->fetch(img, 1000);
				          } while (frameStatus == nvxio::FrameSource::TIMEOUT);
		            }

		            if (frameStatus == nvxio::FrameSource::CLOSED)
		            {
		                std::cerr << "Error: Source has no more frames 1" << std::endl;
		                return -1;
		            }
		            remainingTime -= timeBetweenFrames;
		        }
		    }
        for(int i = framesToSkip_; i >= 0; --i)
        {
		      do
		      {
		          frameStatus = videoSource->fetch(img, 1000);
		      } while (frameStatus == nvxio::FrameSource::TIMEOUT);
	      }

        if (frameStatus == nvxio::FrameSource::CLOSED)
        {
            std::cerr << "Error: Source has no more frames 2" << std::endl;
            return -1;
        }
        return framesSkipped;
    }
    void start()
    {
        timerRead.start();
    }
};

struct EventData
{
    EventData(): shouldStop(false), pause(false) {}
    bool shouldStop;
    bool pause;
};

static void eventCallback(void* eventData, vx_char key, vx_uint32, vx_uint32)
{
    EventData* data = static_cast<EventData*>(eventData);

    if (key == 27)
    {
        data->shouldStop = true;
    }
    else if (key == 32)
    {
        data->pause = !data->pause;
    }
}

static void displayState(nvxio::Render *renderer,
                         const nvxio::FrameSource::Parameters &sourceParams,
                         double proc_ms, double total_ms, float cropMargin)
{
    vx_uint32 renderWidth = renderer->getViewportWidth();

    std::ostringstream txt;
    txt << std::fixed << std::setprecision(1);

    const vx_int32 borderSize = 10;
    nvxio::Render::TextBoxStyle style = {{255, 255, 255, 255}, {0, 0, 0, 127}, {renderWidth / 2 + borderSize, borderSize}};

    txt << "Source size: " << sourceParams.frameWidth << 'x' << sourceParams.frameHeight << std::endl;
    txt << "Algorithm: " << proc_ms << " ms / " << 1000.0 / proc_ms << " FPS" << std::endl;
    txt << "Display: " << total_ms  << " ms / " << 1000.0 / total_ms << " FPS" << std::endl;

    txt << std::setprecision(6);
    txt.unsetf(std::ios_base::floatfield);
    txt << "LIMITED TO " << nvxio::Application::get().getFPSLimit() << " FPS FOR DISPLAY" << std::endl;
    txt << "Space - pause/resume" << std::endl;
    txt << "Esc - close the demo";
    renderer->putTextViewport(txt.str(), style);

    const vx_int32 stabilizedLabelLenght = 100;
    style.origin.x = renderWidth - stabilizedLabelLenght;
    style.origin.y = borderSize;
    renderer->putTextViewport("stabilized", style);

    style.origin.x = renderWidth / 2 - stabilizedLabelLenght;
    renderer->putTextViewport("original", style);

    if (cropMargin > 0)
    {
        vx_uint32 dx = static_cast<vx_uint32>(cropMargin * sourceParams.frameWidth);
        vx_uint32 dy = static_cast<vx_uint32>(cropMargin * sourceParams.frameHeight);
        vx_rectangle_t rect = {dx, dy, sourceParams.frameWidth - dx, sourceParams.frameHeight - dy};

        nvxio::Render::DetectedObjectStyle rectStyle = {{""}, {255, 255, 255, 255}, 2, 0, false};
        renderer->putObjectLocation(rect, rectStyle);
    }
}
#include "config.h"

//#define SHOW
//
// main - Application entry point
//

int main(int argc, char* argv[])
{
    try
    {
        nvxio::Application &app = nvxio::Application::get();
        
        Powermon p;

        //
        // Parse command line arguments
        //

        std::string videoFilePath = "";//app.findSampleFilePath("parking.avi");
        unsigned numOfSmoothingFrames = 5;
        float cropMargin = 0.07f;
        unsigned x = 0;
        int framesToSkip = 0;

        app.setDescription("This demo demonstrates Video Stabilization algorithm");
        app.addOption('s', "source", "Input URI", nvxio::OptionHandler::string(&videoFilePath));
        app.addOption('n', "", "Number of smoothing frames",
                      nvxio::OptionHandler::unsignedInteger(&numOfSmoothingFrames, nvxio::ranges::atLeast(1u) & nvxio::ranges::atMost(6u)));
        app.addOption('x', "", "Execution number",
                      nvxio::OptionHandler::unsignedInteger(&x, nvxio::ranges::atLeast(0u) & nvxio::ranges::atMost(5u)));
        app.addOption(0, "crop", "Crop margin for stabilized frames. If it is negative then the frame cropping is turned off",
                      nvxio::OptionHandler::real(&cropMargin, nvxio::ranges::lessThan(0.5f)));
        app.addOption('f', "", "Frames to skip",
                      nvxio::OptionHandler::integer(&framesToSkip, nvxio::ranges::atLeast(0) & nvxio::ranges::atMost(10)));
        app.init(argc, argv);

        //
        // Create OpenVX context        
        //
#if READER == OPENVX
        ReaderVX reader(videoFilePath, framesToSkip, false);
#elif READER == OPENCV
        ReaderCV reader(videoFilePath, framesToSkip, false);
#endif
        //nvxio::ContextGuard context = reader.context;
        vx_context context = reader.context;
        vxRegisterLogCallback(context, &nvxio::stdoutLogCallback, vx_false_e);
        vxDirective((vx_reference) context, VX_DIRECTIVE_ENABLE_PERFORMANCE);

        //
        // Create FrameSource and Render
        //
#ifdef SHOW
        std::unique_ptr<nvxio::Render> renderer(nvxio::createDefaultRender(
            context, "Video Stabilization Demo", reader.width, reader.height));

        if (!renderer)
        {
            std::cerr << "Error: Can't create a renderer" << std::endl;
            return nvxio::Application::APP_EXIT_CODE_NO_RENDER;
        }
#endif

        EventData eventData;
//        renderer->setOnKeyboardEventCallback(eventCallback, &eventData);

        //
        // Create OpenVX Image to hold frames from video source
        //

        vx_image frameExemplar = vxCreateImage(context,
                                               reader.width, reader.height, VX_DF_IMAGE_RGBX);
        vx_size orig_frame_delay_size = numOfSmoothingFrames + 2; //must have such size to be synchronized with the stabilized frames
        vx_delay orig_frame_delay = vxCreateDelay(context, (vx_reference)frameExemplar, orig_frame_delay_size);
        NVXIO_CHECK_REFERENCE(orig_frame_delay);
        NVXIO_SAFE_CALL( nvx::initDelayOfImages(context, orig_frame_delay) );
        NVXIO_SAFE_CALL(vxReleaseImage(&frameExemplar));

        vx_image frame = (vx_image)vxGetReferenceFromDelay(orig_frame_delay, 0);
        vx_image lastFrame = (vx_image)vxGetReferenceFromDelay(orig_frame_delay,
                                                               1 - static_cast<vx_int32>(orig_frame_delay_size));

        //
        // Create VideoStabilizer instance
        //

        nvx::VideoStabilizer::VideoStabilizerParams params;
        params.numOfSmoothingFrames_ = numOfSmoothingFrames;
        params.cropMargin_ = cropMargin;
        std::unique_ptr<nvx::VideoStabilizer> stabilizer(nvx::VideoStabilizer::createImageBasedVStab(context, params));

        nvxio::FrameSource::FrameStatus frameStatus;

        reader.start();
        reader.read(frame, &p);

        stabilizer->init(frame);

        vx_rectangle_t leftRect;
        NVXIO_SAFE_CALL( vxGetValidRegionImage(frame, &leftRect) );

        vx_rectangle_t rightRect;
        rightRect.start_x = leftRect.end_x;
        rightRect.start_y = leftRect.start_y;
        rightRect.end_x = 2 * leftRect.end_x;
        rightRect.end_y = leftRect.end_y;

        //
        // Run processing loop
        //

        timer::Timer<timer::HOST> TM3;
        //p.start();

        int nFrame = 0;

        std::ofstream times;
        //times.open("times.txt", std::ios::out | std::ios::app);

        uint64_t totalTimeExecution = 0;
        int totalFramesSkipped = 0;

        TM3.start();
        p.resumeCollection();
        reader.start();
        //while (nFrame < 10)
        while (true)
        {
                //
                // Process
                //

                stabilizer->process(frame);
				nFrame++;
#define PATH "./"
#define WRITE(img, destination, x) { char bufferName[100]; { nvx_cv::VXImageToCVMatMapper map(img, 0, NULL, VX_READ_ONLY, VX_MEMORY_TYPE_HOST); sprintf(bufferName, "%s/%s/%05d.png", PATH, destination, nFrame); cv::Mat imgOut; if(x) cv::cvtColor(map.getMat(), imgOut, CV_RGBA2BGRA); else imgOut = map.getMat(); cv::imwrite(std::string(bufferName), imgOut); } }
				//WRITE( frame, "img/0_original" , true);
				//WRITE( stabilizer->getGrayFrame(), "img/1_gray" , false);
				//WRITE( stabilizer->getRemappedFrame(), "img/2_undistort" , false);
				WRITE( stabilizer->getStabilizedFrame(), "img/4_stab_rgb" , true);				
				//WRITE( stabilizer->getStabilizedFrame(), "img/3_stabilized", false );

                NVXIO_SAFE_CALL( vxAgeDelay(orig_frame_delay) );

                //
                // Print performance results
                //

                //stabilizer->printPerfs();

                //
                // Read frame
                //

                TM3.stop();
                totalTimeExecution += TM3.durationNano();



                //
                // Read frame
                //
                /*M(TM2, tot_time_read,
    if(!reader.read(img)) break;
    );*/
                int framesSkipped = reader.read(frame, &p);
                totalFramesSkipped += framesSkipped;
                if(framesSkipped < 0)
				{
					totalFramesSkipped += 1;
					break;
				}

                if(times.is_open())
                {
                    times << x << ";";
                    times << (( READER        == OPENCV ) ? "OPENCV" : "OPENVX") << ";";
                    times << (( CVT_COLOR     == CPU    ) ? "CPU"    : "GPU"  ) << ";";
                    times << (( REMAP         == CPU    ) ? "CPU"    : "GPU"  ) << ";";
                    times << (( FEATURES      == CPU    ) ? "CPU"    : "GPU"  ) << ";";
                    times << (( FEATURES_TYPE == HARRIS ) ? "HARRIS" : "FAST" ) << ";";
                    times << (( FEATURES_IMPL == OPENVX_IMPL ) ? "OPENVX" : "VISIONWORKS" ) << ";";
                    times << (( OPTICAL_FLOW  == CPU    ) ? "CPU"    : "GPU"  ) << ";";
                    times << (( WARP          == CPU    ) ? "CPU"    : "GPU"  ) << ";";
                    times << TM3.durationNano() << ";";
                    times << framesSkipped << ";";
                    times << std::endl;
                }
                TM3.start();

#ifdef SHOW
                renderer->putImage(stabilizer->getStabilizedFrame());
                if (!renderer->flush())
                {
                //    eventData.shouldStop = true;
                }
#endif

                p.resumeCollection();
                reader.start();
        }
        p.stop();
        std::cout << "End" << std::endl;
        std::cout << nFrame << std::endl;

				bool writeHeader = false;
        {
        	std::ifstream input("results.txt");
        	writeHeader = !input.good();
        }
        std::ofstream output;
        output.open("results.txt", std::ios::out | std::ios::app);
        if(output.is_open())
        {
        	if(writeHeader)
					{
						output << "Filename;";
						output << "Number of try;";
						output << "Reader;";
						output << "Convert color;";
						output << "Remap;";
						output << "Features;";
						output << "Features type;";
						output << "Features implementation;";
						output << "Pyramid build;";
						output << "Optical flow;";
						output << "Warp;";
						output << "Total frames processed;";
						output << "Total time executed (ns);";
						output << "Power avg;";
						output << "Power max;";
						output << "Power total;";
						output << "Sampled instants;";
						output << "Frames to skip;";
						output << "TotalFrames skipped;";
						output << std::endl;
					}
          output << videoFilePath << ";";
          output << x << ";";
          output << (( READER        == OPENCV ) ? "OPENCV" : "OPENVX" ) << ";";
          output << (( CVT_COLOR     == CPU    ) ? "CPU"    : "GPU"    ) << ";";
          output << (( REMAP         == CPU    ) ? "CPU"    : "GPU"    ) << ";";
          output << (( FEATURES      == CPU    ) ? "CPU"    : "GPU"    ) << ";";
          output << (( FEATURES_TYPE == HARRIS ) ? "HARRIS" : "FAST"   ) << ";";
          output << (( FEATURES_IMPL == OPENVX_IMPL ) ? "OPENVX" : "VISIONWORKS" ) << ";";
          output << (( PYRAMID  == CPU    ) ? "CPU"    : "GPU"    ) << ";";
          output << (( OPTICAL_FLOW  == CPU    ) ? "CPU"    : "GPU"    ) << ";";
          output << (( WARP          == CPU    ) ? "CPU"    : "GPU"    ) << ";";
          output << nFrame << ";";
          output << totalTimeExecution << ";";
          output << p.getPowerAvg() << ";";
          output << p.getPowerMax() << ";";
          output << p.getPowerTotal() << ";";
          output << p.getSampledInstants() << ";";
          output << framesToSkip << ";";
          output << totalFramesSkipped << ";";
          output << std::endl;
        }
        output.close();
//        times.close();

        double total_time = 0;

        stabilizer->printSumPerfs();
        stabilizer->printAvgPerfs();
        /*		std::cout << "Power avg: " << p.getPowerAvg() << std::endl;
				std::cout << "Power max: " << p.getPowerMax() << std::endl;
				std::cout << "Timer dur: " << total_time << std::endl;
                std::cout << "Tot energy: " << (total_time)*p.getPowerAvg()/1000 << std::endl;*/

        //
        // Release all objects
        //
        vxReleaseDelay(&orig_frame_delay);
    }
    catch (const std::exception& e)
    {
        std::cerr << "Error: " << e.what() << std::endl;
        return nvxio::Application::APP_EXIT_CODE_ERROR;
    }

    return nvxio::Application::APP_EXIT_CODE_SUCCESS;
}
