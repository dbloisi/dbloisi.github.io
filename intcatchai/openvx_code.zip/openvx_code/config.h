#define CPU 0
#define GPU 1

#define OPENCV 0
#define OPENVX 1

#define HARRIS 0
#define FASTT   1

#define OPENVX_IMPL 0
#define VISIONWORKS_IMPL 1


//default values if not defined
#ifndef READER
#define READER OPENVX
#endif

#ifndef CVT_COLOR
#define CVT_COLOR GPU
#endif

#ifndef REMAP
#define REMAP GPU
#endif

#ifndef PYRAMID
#define PYRAMID GPU
#endif

#ifndef OPTICAL_FLOW
#define OPTICAL_FLOW GPU
#endif

#ifndef FEATURES
#define FEATURES GPU
#endif

#ifndef FEATURES_TYPE
#define FEATURES_TYPE HARRIS
#endif

#ifndef FEATURES_IMPL
#define FEATURES_IMPL OPENVX
#endif

#ifndef WARP
#define WARP GPU
#endif

#if READER != OPENVX && READER != OPENCV
#error READER must be set to OPENCV or OPENVX
#endif

#if REMAP != CPU && REMAP != GPU
#error REMAP must be set to CPU or GPU
#endif

#if CVT_COLOR != CPU && CVT_COLOR != GPU
#error CVT_COLOR must be set to CPU or GPU
#endif

#if OPTICAL_FLOW != CPU && OPTICAL_FLOW != GPU
#error OPTICAL_FLOW must be set to CPU or GPU
#endif

#if PYRAMID != CPU && PYRAMID != GPU
#error PYRAMID must be set to CPU or GPU
#endif

#if FEATURES != CPU && FEATURES != GPU
#error FEATURES must be set to CPU or GPU
#endif

#if FEATURES_TYPE != HARRIS && FEATURES_TYPE != FASTT
#error FEATURES_TYPE must be set to HARRIS or FASTT
#endif

#if FEATURES_IMPL != OPENVX_IMPL && FEATURES_IMPL != VISIONWORKS_IMPL
#error FEATURES_IMPL must be set to OPENVX_IMPL or VISIONWORKS_IMPL
#endif

#if WARP != CPU && WARP != GPU
#error WARP must be set to CPU or GPU
#endif
