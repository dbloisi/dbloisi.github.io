#!/bin/bash
#nvcc -O3 -std=c++11 mainClean.cpp -lopencv_core -lopencv_imgproc -lopencv_calib3d -lopencv_video -lopencv_features2d -lopencv_highgui initFrames.cpp powermon.cpp Timer.cpp -o videoOpenCV.x
#service lightdm stop

READER=(1) #OpenCV, OpenVX
REMAP=(1) #CPU, GPU
CVT_COLOR=(1) #CPU, GPU
PYRAMID=(1) #CPU, GPU
OPTICAL_FLOW=(0 1) #CPU, GPU
FEATURES=(0 1) #CPU, GPU
FEATURES_TYPE=(0 1) #Harris, FAST
FEATURES_IMPL=(0 1) #OpenVX, VisionWorks
WARPS=(1) #CPU, GPU
JUMPS=(0) #frames skipped

N=1
FILES=(../data/highres-fsr2017/prophr1.mp4) # ../data/highres-fsr2017/prophr2.mp4 ../data/highres-fsr2017/prophr3.mp4) # ../data/lowres-fsr2017/proplr1.avi ../data/lowres-fsr2017/proplr2.avi ../data/lowres-fsr2017/proplr3.avi)

for reader_ in ${READER[*]}
do 
	for remap_ in ${REMAP[*]}
	do 
		for cvt_color_ in ${CVT_COLOR[*]}
		do
			for pyramid_ in ${PYRAMID[*]}
			do
				for opt_ in ${OPTICAL_FLOW[*]}
				do
					for features_ in ${FEATURES[*]}
					do
						for features_impl_ in ${FEATURES_IMPL[*]}
						do
							for features_type_ in ${FEATURES_TYPE[*]}
							do
								for warps_ in ${WARPS[*]}
								do
		echo BEGINLINE  -D READER=$reader_ -D REMAP=$remap_ -D CVT_COLOR=$cvt_color_ -D PYRAMID=$pyramid_ -D OPTICAL_FLOW=$opt_ -D FEATURES=$features_ -D FEATURES_TYPE=$features_type_ -D FEATURES_IMPL=$features_impl_ -D WARPS=$warps_ >> out.txt;
		g++ -I/usr/include/eigen3 -O3 -D READER=$reader_ -D REMAP=$remap_ -D CVT_COLOR=$cvt_color_ -D PYRAMID=$pyramid_ -D OPTICAL_FLOW=$opt_ -D FEATURES=$features_ -D FEATURES_TYPE=$features_type_ -D FEATURES_IMPL=$features_impl_ -D WARPS=$warps_ -pthread -std=c++11 -DCUDA_API_PER_THREAD_DEFAULT_STREAM -DUSE_GUI=1 -DUSE_GLFW=1 -DUSE_GLES=1 -DUSE_GSTREAMER=1 -DUSE_NVGSTCAMERA=1 -DUSE_GSTREAMER_OMX=1  -O3 -DNDEBUG -std=c++11 -o videoOpenVX.x homography_filter_node.cpp main_video_stabilizer.cpp smoother_node.cpp stabilizer.cpp truncate_transform_node.cpp powermon.cpp Timer.cpp -lnvxio -lvisionworks `pkg-config opencv --libs --cflags` &&
		for i in ${JUMPS[*]}; do
		for f in ${FILES[*]} ; do
		for ntry in `eval echo {1..$N}` ; do
		./videoOpenVX.x -x $ntry -f $i -s $f 1>>out.txt 2>>out.txt;
		done
		done
		done
								done
							done
						done
					done
				done
			done
		done
	done
done
