#!/bin/bash
#nvcc -O3 -std=c++11 homography_filter_node.cpp main_video_stabilizer.cpp smoother_node.cpp stabilizer.cpp truncate_transform_node.cpp powermon.cpp Timer.cpp -lnvxio -lvisionworks -I/usr/include/eigen3 -o videoOpenVX.x `pkg-config opencv --libs --cflags`

g++  -I/usr/include/eigen3  -DCUDA_API_PER_THREAD_DEFAULT_STREAM -DUSE_GUI=1 -DUSE_GLFW=1 -DUSE_GLES=1 -DUSE_GSTREAMER=1 -DUSE_NVGSTCAMERA=1 -DUSE_GSTREAMER_OMX=1  -O3 -DNDEBUG -std=c++11 -o videoOpenVX.x homography_filter_node.cpp main_video_stabilizer.cpp smoother_node.cpp stabilizer.cpp truncate_transform_node.cpp powermon.cpp Timer.cpp -lnvxio -lvisionworks `pkg-config opencv --libs --cflags`
