#!/bin/bash
#nvcc -O3 -std=c++11 mainClean.cpp -lopencv_core -lopencv_imgproc -lopencv_calib3d -lopencv_video -lopencv_features2d -lopencv_highgui initFrames.cpp powermon.cpp Timer.cpp -o videoOpenCV.x
#service lightdm stop

JUMPS=(0) #frames skipped

N=1
FILES=(../data/highres-fsr2017/prophr1.mp4 ../data/highres-fsr2017/prophr2.mp4 ../data/highres-fsr2017/prophr3.mp4) # ../data/lowres-fsr2017/proplr1.avi ../data/lowres-fsr2017/proplr2.avi ../data/lowres-fsr2017/proplr3.avi)

g++ -O3 -D READER=1 -D REMAP=0 -D CVT_COLOR=0 -D PYRAMID=1 -D OPTICAL_FLOW=1 -D FEATURES=0 -D FEATURES_TYPE=0 -D WARPS=0 -pthread -std=c++11 mainClean.cpp powermon.cpp Timer.cpp -lopencv_core -lopencv_imgproc -lopencv_calib3d -lopencv_video -lopencv_features2d -lopencv_highgui -lopencv_gpu -lnvxio -lvisionworks -o videoOpenCV.x &&
		for i in ${JUMPS[*]}; do
		for f in ${FILES[*]} ; do
		for ntry in `eval echo {1..$N}` ; do
		  ./videoOpenCV.x -x $ntry -f $i -s $f 1>>out.txt 2>>out.txt;
		done
		done
		done

g++ -O3 -D READER=1 -D REMAP=0 -D CVT_COLOR=0 -D PYRAMID=1 -D OPTICAL_FLOW=1 -D FEATURES=0 -D FEATURES_TYPE=1 -D WARPS=0 -pthread -std=c++11 mainClean.cpp powermon.cpp Timer.cpp -lopencv_core -lopencv_imgproc -lopencv_calib3d -lopencv_video -lopencv_features2d -lopencv_highgui -lopencv_gpu -lnvxio -lvisionworks -o videoOpenCV.x &&
		for i in ${JUMPS[*]}; do
		for f in ${FILES[*]} ; do
		for ntry in `eval echo {1..$N}` ; do
		  ./videoOpenCV.x -x $ntry -f $i -s $f 1>>out.txt 2>>out.txt;
		done
		done
		done


g++ -O3 -D READER=1 -D REMAP=0 -D CVT_COLOR=0 -D PYRAMID=1 -D OPTICAL_FLOW=1 -D FEATURES=1 -D FEATURES_TYPE=0 -D WARPS=0 -pthread -std=c++11 mainClean.cpp powermon.cpp Timer.cpp -lopencv_core -lopencv_imgproc -lopencv_calib3d -lopencv_video -lopencv_features2d -lopencv_highgui -lopencv_gpu -lnvxio -lvisionworks -o videoOpenCV.x &&
		for i in ${JUMPS[*]}; do
		for f in ${FILES[*]} ; do
		for ntry in `eval echo {1..$N}` ; do
		  ./videoOpenCV.x -x $ntry -f $i -s $f 1>>out.txt 2>>out.txt;
		done
		done
		done

g++ -O3 -D READER=1 -D REMAP=0 -D CVT_COLOR=0 -D PYRAMID=1 -D OPTICAL_FLOW=1 -D FEATURES=1 -D FEATURES_TYPE=1 -D WARPS=0 -pthread -std=c++11 mainClean.cpp powermon.cpp Timer.cpp -lopencv_core -lopencv_imgproc -lopencv_calib3d -lopencv_video -lopencv_features2d -lopencv_highgui -lopencv_gpu -lnvxio -lvisionworks -o videoOpenCV.x &&
		for i in ${JUMPS[*]}; do
		for f in ${FILES[*]} ; do
		for ntry in `eval echo {1..$N}` ; do
		  ./videoOpenCV.x -x $ntry -f $i -s $f 1>>out.txt 2>>out.txt;
		done
		done
		done

