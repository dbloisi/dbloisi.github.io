#include <opencv2/opencv.hpp>
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/features2d/features2d.hpp>
#include <opencv2/video/video.hpp>
#include <opencv2/calib3d/calib3d.hpp>
#include <opencv2/calib3d/calib3d.hpp>
#include <opencv2/gpu/gpu.hpp>
#include <iostream>
#include <string>
#include <sstream>
#include <deque>
#include <iomanip>
#include "powermon.hpp"
#include "Timer.hpp"
#include <thread>
#include <fstream>

#include <sstream>

const int NUM_FRAMES = 5;


#define isGoodPointM(v) isGoodPoint(t,w,h,r,f,v)

bool isGoodPoint(cv::Mat t, int w, int h, cv::Mat r, float f, cv::Vec3f p)
{
    cv::Mat_<float> tmp = ((1-f)*t+f*r)*cv::Mat_<float>(p, false);
    cv::Vec3f nP = tmp;

    float x = nP[0] / nP[2];
    float y = nP[1] / nP[2];

    return x >= 0 && x < (w -1)
            && y >= 0 && y < (h -1);
}
bool isGood(cv::Mat t, int w, int h, cv::Mat r, float f)
{
    return isGoodPointM(cv::Vec3f(0, 0, 1)) &&
            isGoodPointM(cv::Vec3f(w-1, 0, 1)) &&
            isGoodPointM(cv::Vec3f(0, h-1, 1)) &&
            isGoodPointM(cv::Vec3f(w-1, h-1, 1));

}

bool tTransf(cv::Mat_<float> transform, int w, int h, cv::Mat_<float> rM, cv::Mat_<float>& tT)
{
    float t = 0;
    if(isGood(transform, w, h, rM, t))
    {
        return false;
    }
    float l = 0, r = 1;
    while (r - l > 1e-2f)
    {
        t = (l + r) * 0.5f;
        if ( isGood(transform, w, h, rM, t) )
            r = t;
        else
            l = t;
    }

    tT = (1 - t) * transform + t * rM;

    return true;

}
cv::Mat truncateTransform(cv::Mat& transform, cv::Mat& frame)
{
    //deciso a priori
    float crop = 0.07f;

    cv::Mat_<float> resizeM = cv::Mat_<float>::eye(3,3);
    float scale = 1.0f / (1.0f - 2 * crop);
    resizeM.at<float>(0, 0) = resizeM.at<float>(1,1) = scale;
    resizeM.at<float>(0, 2) = - scale * frame.cols * crop;
    resizeM.at<float>(1, 2) = - scale * frame.rows * crop;

    cv::Mat_<float> stabT = transform.t();

    stabT = resizeM * stabT;
    cv::Mat_<float> invStabT = stabT.inv();
    cv::Mat_<float> invRes = resizeM.inv();

    cv::Mat_<float> invTruncTransf;
    bool b = tTransf(invStabT, frame.cols, frame.rows, invRes, invTruncTransf);
    if(b)
    {
        stabT = invTruncTransf.inv();
    }

    stabT = stabT.t();
    invStabT = stabT.inv();

    return invStabT;
}
cv::Mat truncateTransform(cv::Mat& transform, cv::gpu::GpuMat& frame)
{
    //deciso a priori
    float crop = 0.07f;

    cv::Mat_<float> resizeM = cv::Mat_<float>::eye(3,3);
    float scale = 1.0f / (1.0f - 2 * crop);
    resizeM.at<float>(0, 0) = resizeM.at<float>(1,1) = scale;
    resizeM.at<float>(0, 2) = - scale * frame.cols * crop;
    resizeM.at<float>(1, 2) = - scale * frame.rows * crop;

    cv::Mat_<float> stabT = transform.t();

    stabT = resizeM * stabT;
    cv::Mat_<float> invStabT = stabT.inv();
    cv::Mat_<float> invRes = resizeM.inv();

    cv::Mat_<float> invTruncTransf;
    bool b = tTransf(invStabT, frame.cols, frame.rows, invRes, invTruncTransf);
    if(b)
    {
        stabT = invTruncTransf.inv();
    }

    stabT = stabT.t();
    invStabT = stabT.inv();

    return invStabT;
}

cv::Mat filter(cv::Mat m, int nInlier, int pSize, cv::Size imgSize)
{
    int inlTresh = std::max(15, static_cast<int>(0.1 * pSize));
    cv::Mat_<float> eye = cv::Mat_<float>::eye(3,3);
    if(nInlier < inlTresh) return eye;

    cv::Mat_<float> vertices(cv::Size(4,3), 0);
    int width = imgSize.width;
    int height = imgSize.height;
    vertices.at<float>(0, 1) = static_cast<float>(width);
    vertices.at<float>(0, 2) = static_cast<float>(width);
    vertices.at<float>(1, 2) = static_cast<float>(height);
    vertices.at<float>(1, 3) = static_cast<float>(height);
    for(int i=0; i<4; ++i)
        vertices.at<float>(2, i) = 1.0f;
    cv::Mat_<float> dstVertices = m * vertices;
    for(int i=0; i<4; ++i)
    {
        dstVertices.at<float>(0,i) /= dstVertices.at<float>(2,i);
        dstVertices.at<float>(1,i) /= dstVertices.at<float>(2,i);
        dstVertices.at<float>(2,i) = 1.0f;
    }

    float diagLenGold = std::sqrt(static_cast<float>(width*width + height*height));

    float dx = dstVertices.at<float>(0,0) - dstVertices.at<float>(0,2);
    float dy = dstVertices.at<float>(1,0) - dstVertices.at<float>(1,2);
    float lenDiag1 = sqrt(dx*dx + dy*dy);

    dx = dstVertices.at<float>(0,1) - dstVertices.at<float>(0,3);
    dy = dstVertices.at<float>(1,1) - dstVertices.at<float>(1,3);
    float lenDiag2 = sqrt(dx*dx + dy*dy);

    float averDiagLen = (lenDiag1 + lenDiag2) / 2;
    float diagRatio1 = std::min(diagLenGold, averDiagLen) / std::max(diagLenGold, averDiagLen);
    if (diagRatio1 < 0.5f) {return eye;}

    float maxDiag = std::max(lenDiag1, lenDiag2);
    if (maxDiag > 0.0f)
    {
        float diagRatio2 = std::min(lenDiag1, lenDiag2) / maxDiag;
        if (diagRatio2 < 0.25f)
        {
            return eye;
        }
    }
    else
    {
        return eye;
    }
    cv::SVD svdM(m);
    if(svdM.w.at<float>(2,0) < 1e-4f) {return eye;}

    return m;
}

cv::Mat getTransformation(std::deque<cv::Mat>& mats, int from, int to)
{
    cv::Mat_<float> M = cv::Mat_<float>::eye(3,3);

    if (to > from)
    {
        for (int i = from; i < to; ++i)
        {
            M = M * mats[i];
        }
    }
    else if (to < from)
    {
        for (int i = to; i < from; ++i)
        {
            M = M * mats[i];
        }

        M = M.inv();
    }

    return M;
}
cv::Mat smoothMatrix(std::deque<cv::Mat>& mtx)
{
    int num = mtx.size();
    int nM = num / 2;

    std::vector<float> gaussWeights(num);
    float sigma = nM * 0.7f;
    float sum = 0;
    for(int i = -nM; i < num-nM; ++i)
    {
        sum += (gaussWeights[i+nM] = exp( - i * i / (2.f * sigma * sigma) ));
    }
    for(int i = 0; i < gaussWeights.size(); i++) gaussWeights[i] /= sum;

    cv::Mat avg = cv::Mat::zeros(3,3, mtx[0].type());
    int idx = nM;
    for (int i = idx-nM; i <= idx+nM; ++i)
    {
        cv::Mat M = getTransformation(mtx, idx, i);
        avg += gaussWeights[i - idx + nM] * getTransformation(mtx, idx, i);
    }

    return avg;
}

static void download(const cv::gpu::GpuMat &d_mat, std::vector<cv::Point2f>& vec)
{
    vec.resize(d_mat.cols);
    cv::Mat mat(1, d_mat.cols, CV_32FC2, (void*) &vec[0]);
    d_mat.download(mat);
}
static void download(const cv::gpu::GpuMat &d_mat, std::vector<uchar>& vec)
{
    vec.resize(d_mat.cols);
    cv::Mat mat(1, vec.size(), CV_8UC1, (void*) &vec[0]);
    d_mat.download(mat);
}

static void upload(cv::gpu::GpuMat &d_mat, const std::vector<cv::Point2f>& vec)
{
    cv::Mat mat(1, vec.size(), CV_32FC2, (void*) &vec[0]);
    d_mat.upload(mat);
}
static void upload(cv::gpu::GpuMat &d_mat, const std::vector<uchar>& vec)
{
    cv::Mat mat(1, d_mat.cols, CV_8UC1, (void*) &vec[0]);
    d_mat.upload(mat);
}

#include <NVX/nvx.h>
#include <NVX/nvx_opencv_interop.hpp>
#include <NVXIO/Application.hpp>
#include <NVXIO/FrameSource.hpp>
#include <NVXIO/Render.hpp>
#include <NVXIO/SyncTimer.hpp>
#include <NVXIO/Utility.hpp>

class ReaderCV
{
private:
    cv::VideoCapture cap;
    cv::Mat frame;
    uint32_t width, height;
    uint64_t timeBetweenFrames; //ns
    int64_t remainingTime; //ns
    timer::Timer<timer::HOST> timerRead;
    
    int framesToSkip_;
public:
    ReaderCV(std::string videoFilePath, int framesToSkip)
        :
          cap(videoFilePath),
          framesToSkip_(framesToSkip)
    {
        if(!cap.isOpened()) std::cerr << "Error opening video!" << std::endl;

        width  = static_cast<uint32_t>(cap.get(CV_CAP_PROP_FRAME_WIDTH));
        height = static_cast<uint32_t>(cap.get(CV_CAP_PROP_FRAME_HEIGHT));

        double fps = cap.get(CV_CAP_PROP_FPS);
        timeBetweenFrames = (framesToSkip + 1) * static_cast<uint64_t>(1000000000 / fps);//time in nanosecond
        remainingTime = 0;
    }

    int read(cv::Mat& imgCV, Powermon* p)
    {
        timerRead.stop();
        int framesSkipped = 0;
        remainingTime += timerRead.durationNano();
        //advance of 1 timestep
        remainingTime -= timeBetweenFrames;
        if(remainingTime < 0) //finished before, need to wait
        {
            std::this_thread::sleep_for(std::chrono::nanoseconds(-remainingTime));
            remainingTime = 0;
            p->pauseCollection();
        }
        else //skip n timesteps (minus the one that i read)
        {
		        p->pauseCollection();
            while(remainingTime > timeBetweenFrames)
            {
                ++framesSkipped;
                for(int i = framesToSkip_; i >= 0; --i) if(!cap.grab()) return -1;
                remainingTime -= timeBetweenFrames;
            }
        }

        bool res = true;
        for(int i = framesToSkip_ - 1; i >= 0; --i) res &= cap.grab();
        res &= cap.read(imgCV);
        
        if(res) return framesSkipped;
        else    return -1;
    }
    void start()
    {
        timerRead.start();
    }
};
class ReaderVX
{
private:
    nvxio::ContextGuard context;
    std::unique_ptr<nvxio::FrameSource> videoSource;
    vx_image img;
    uint32_t width, height;

    uint64_t timeBetweenFrames; //ns
    int64_t remainingTime; //ns
    timer::Timer<timer::HOST> timerRead;
    
    int framesToSkip_;

public:
    ReaderVX(std::string videoFilePath, int framesToSkip)
        :
          context(),
          videoSource(nvxio::createDefaultFrameSource(context, videoFilePath)),
          framesToSkip_(framesToSkip)
    {
        NVXIO_CHECK_REFERENCE((vx_reference) context);
        if (!videoSource || !videoSource->open())
        {
            std::cerr << "Error: Can't open source file: " << videoFilePath << std::endl;
            //return nvxio::Application::APP_EXIT_CODE_NO_RESOURCE;
        }

        if (videoSource->getSourceType() == nvxio::FrameSource::SINGLE_IMAGE_SOURCE)
        {
            std::cerr << "Error: Can't work on a single image." << std::endl;
            //return nvxio::Application::APP_EXIT_CODE_INVALID_FORMAT;
        }
        nvxio::FrameSource::Parameters sourceParams = videoSource->getConfiguration();
        img = vxCreateImage(context, sourceParams.frameWidth, sourceParams.frameHeight, VX_DF_IMAGE_RGBX);
        width  = sourceParams.frameWidth;
        height = sourceParams.frameHeight;

        uint32_t fps = sourceParams.fps+1;//to get 60 fps
        timeBetweenFrames = (framesToSkip + 1) * static_cast<uint64_t>(1000000000 / static_cast<double>(fps));//time in nanosecond
        remainingTime = 0;
    }

    ~ReaderVX()
    {
        videoSource->close();
        vxReleaseImage(&img);
    }
    int read(cv::Mat& imgCV, Powermon *p)
    {
        timerRead.stop();
        NVXIO_CHECK_REFERENCE((vx_reference) context);
        nvxio::FrameSource::FrameStatus frameStatus;
        
        int framesSkipped = 0;
        remainingTime += timerRead.durationNano();
        //advance of 1 timestep
        remainingTime -= timeBetweenFrames;

        if(remainingTime < 0) //finished before, need to wait
        {
            std::this_thread::sleep_for(std::chrono::nanoseconds(-remainingTime));
            remainingTime = 0;
            p->pauseCollection();
        }
        else //skip n timesteps (minus the one that i read)
        {
		    p->pauseCollection();
            while(remainingTime > timeBetweenFrames)
            {
                framesSkipped++;
                for(int i = framesToSkip_; i >= 0; --i)
				  do
				  {
				      frameStatus = videoSource->fetch(img, 1000);
				  } while (frameStatus == nvxio::FrameSource::TIMEOUT);

                if (frameStatus == nvxio::FrameSource::CLOSED)
                {
                    std::cerr << "Error: Source has no more frames 1" << std::endl;
                    return -1;
                }
                remainingTime -= timeBetweenFrames;
            }
        }
        
        for(int i = framesToSkip_; i >= 0; --i)
		      do
		      {
		          frameStatus = videoSource->fetch(img, 1000);
		      } while (frameStatus == nvxio::FrameSource::TIMEOUT);

        if (frameStatus == nvxio::FrameSource::CLOSED)
        {
            std::cerr << "Error: Source has no more frames 2" << std::endl;
            return -1;
        }
        {
            vx_uint32 plane_index = 0;
            nvx_cv::VXImageToCVMatMapper map(img, plane_index, NULL, VX_READ_ONLY, VX_MEMORY_TYPE_HOST);
            cv::Mat imgOut;
            cv::cvtColor(map.getMat(), imgOut, CV_RGBA2BGR);
            imgOut.copyTo(imgCV);
        }
        return framesSkipped;
    }
    void start()
    {
        timerRead.start();
    }
};

#define CPU 0
#define GPU 1

#define OPENCV 0
#define OPENVX 1

#define HARRIS 0
#define FAST 1

//default values if not defined
#ifndef READER
#define READER OPENVX
#endif

#ifndef REMAP
#define REMAP GPU
#endif

#ifndef CVT_COLOR
#define CVT_COLOR GPU
#endif

#ifndef OPTICAL_FLOW
#define OPTICAL_FLOW GPU
#endif

#ifndef FEATURES
#define FEATURES GPU
#endif

#ifndef FEATURES_TYPE
#define FEATURES_TYPE FAST
#endif

#ifndef WARP
#define WARP GPU
#endif

#if READER != OPENVX && READER != OPENCV
#error READER must be set to OPENCV or OPENVX
#endif

#if REMAP != CPU && REMAP != GPU
#error REMAP must be set to CPU or GPU
#endif

#if CVT_COLOR != CPU && CVT_COLOR != GPU
#error CVT_COLOR must be set to CPU or GPU
#endif

#if OPTICAL_FLOW != CPU && OPTICAL_FLOW != GPU
#error OPTICAL_FLOW must be set to CPU or GPU
#endif

#if FEATURES != CPU && FEATURES != GPU
#error FEATURES must be set to CPU or GPU
#endif

#if FEATURES_TYPE != HARRIS && FEATURES_TYPE != FAST
#error FEATURES_TYPE must be set to HARRIS or FAST
#endif

#if WARP != CPU && WARP != GPU
#error WARP must be set to CPU or GPU
#endif


int main(int argc, char* argv[])
{
    //check on defined values
    // end check
    try
    {
        nvxio::Application &app = nvxio::Application::get();
        //
        // Parse command line arguments
        //

        std::string videoFilePath = "";//app.findSampleFilePath("parking.avi");
        unsigned numOfSmoothingFrames = 5;
        float cropMargin = 0.07f;
        unsigned x = 0;
        int framesToSkip = 0;

        app.setDescription("This demo demonstrates Video Stabilization algorithm");
        app.addOption('s', "source", "Input URI", nvxio::OptionHandler::string(&videoFilePath));
        app.addOption('n', "", "Number of smoothing frames",
                      nvxio::OptionHandler::unsignedInteger(&numOfSmoothingFrames, nvxio::ranges::atLeast(1u) & nvxio::ranges::atMost(6u)));
        app.addOption('x', "", "Execution number",
                      nvxio::OptionHandler::unsignedInteger(&x, nvxio::ranges::atLeast(0u) & nvxio::ranges::atMost(10u)));
        app.addOption(0, "crop", "Crop margin for stabilized frames. If it is negative then the frame cropping is turned off",
                      nvxio::OptionHandler::real(&cropMargin, nvxio::ranges::lessThan(0.5f)));
        app.addOption('f', "", "Frames to skip",
                      nvxio::OptionHandler::integer(&framesToSkip, nvxio::ranges::atLeast(0) & nvxio::ranges::atMost(10)));
        app.init(argc, argv);

#if READER==OPENVX
        ReaderVX reader(videoFilePath, framesToSkip);
#elif READER==OPENCV
				ReaderCV reader(videoFilePath, framesToSkip);
#endif

        //init
        Powermon p;
        timer::Timer<timer::HOST> TM;
        timer::Timer<timer::HOST> TM2;
        timer::Timer<timer::HOST> TM3;

        //constant
        const int    N_POINTS          = 1000;
        const double QUALITY_LEVEL     = 0.01;
        const double MIN_DISTANCE      = 18;
        const double HARRIS_BLOCK_SIZE = 3;
        const double HARRIS_K          = 0.04;

        const cv::Size winSizeOfFlow(20, 20);
        const int LK_MAX_LEVEL_PYRAMID = 6;
        const int LK_ITERATIONS        = 10;


        //data
        cv::Mat img_read, img_gray, img_undistort, img_previous;
        cv::gpu::GpuMat d_img_read, d_img_gray, d_img_undistort, d_img_previous;

        //remap
        cv::Mat mapX, mapY;
        cv::gpu::GpuMat mapX_gpu, mapY_gpu;

        //detection
        //cv::FeatureDetector detector_cpu = cv::GoodFeaturesToTrackDetector(1000, 0.01, 18, 3, true, 0.04);

#if FEATURES_TYPE == HARRIS
        cv::GoodFeaturesToTrackDetector detector_cpu(N_POINTS, QUALITY_LEVEL, MIN_DISTANCE, HARRIS_BLOCK_SIZE, true, HARRIS_K);
        cv::gpu::GoodFeaturesToTrackDetector_GPU detector_gpu(N_POINTS, QUALITY_LEVEL, MIN_DISTANCE, HARRIS_BLOCK_SIZE, true, HARRIS_K);
#elif FEATURES_TYPE == FAST
        cv::FastFeatureDetector detector_cpu(50, true);
        cv::gpu::FAST_GPU detector_gpu(50, true, 0.05);
#endif

        //optical flow data
        //cpu
        std::vector<cv::Mat> pyramid_cur, pyramid_old;
        std::vector<cv::Point2f> points, points_est;
        std::vector<uchar> status;
        std::vector<float> error;

        //gpu
        cv::gpu::GpuMat dPoints, dPointsEst;
        cv::gpu::GpuMat dStatus;
        cv::gpu::PyrLKOpticalFlow d_pyrLK;
        d_pyrLK.winSize.width = winSizeOfFlow.width;
        d_pyrLK.winSize.height = winSizeOfFlow.height;
        d_pyrLK.maxLevel = LK_MAX_LEVEL_PYRAMID;
        d_pyrLK.iters    = LK_ITERATIONS;
        d_pyrLK.useInitialFlow = false;


        cv::gpu::GpuMat framesGPU[8];
        cv::Mat framesCPU[8];
        double tot_time_read = 0;

        //init
        reader.start();
        reader.read(img_read, &p);
        d_img_read.upload(img_read);

        cv::Mat mapx, mapy;
        cv::Mat cM = (cv::Mat_<double>(3,3) << 835.555, 0, 957.081,0, 835.555, 531.063, 0, 0, 1);
        cv::Mat par =  (cv::Mat_<double>(1,5) << -0.220777, 0.0680066, 0, 0, -0.0116103);
        cv::Mat newM;
        initUndistortRectifyMap(cM, par, cv::Mat_<double>::eye(3,3), newM, img_read.size(), CV_32FC1, mapx, mapy);
        convertMaps(mapx, mapy, mapX, mapY, CV_16SC2, false);//to change on true
        //mapX = mapx.clone();
        //mapY = mapY.clone();
        mapX_gpu.upload(mapx);
        mapY_gpu.upload(mapy);

        cv::gpu::GpuMat dImgWarped;

        //giro a vuoto per inizializzare tutto
        //init mtx
        std::deque<cv::Mat> mats;
        cv::Mat imgTmpGray;
        cv::Mat imgTmpUndistort;
        cv::gpu::GpuMat imgTmpGray_gpu;
        cv::gpu::GpuMat imgTmpUndistort_gpu;

        //do first steps
        cv::gpu::cvtColor(d_img_read, imgTmpGray_gpu, CV_BGR2GRAY);
        cv::cvtColor(img_read, imgTmpGray, CV_BGR2GRAY);

        cv::gpu::remap(imgTmpGray_gpu, imgTmpUndistort_gpu, mapX_gpu, mapY_gpu, CV_INTER_LINEAR);
        cv::remap(imgTmpGray, imgTmpUndistort, mapX, mapY, CV_INTER_LINEAR);
        
        //detector_cpu.detect(img_undistort, points);

        cv::goodFeaturesToTrack(imgTmpUndistort, points, 1000, 0.01, 18, cv::noArray(), 3, true, 0.04);
#if FEATURES_TYPE==HARRIS
        detector_gpu(imgTmpUndistort_gpu, dPoints);
        download(dPoints, points);
        upload(dPointsEst, points);
#elif FEATURES_TYPE==FAST
#endif

        cv::buildOpticalFlowPyramid(imgTmpUndistort, pyramid_cur, winSizeOfFlow, LK_MAX_LEVEL_PYRAMID, true);

        for(int i = 0; i < 1+2*NUM_FRAMES; i++) mats.push_front(cv::Mat_<float>::eye(3,3));
        //init gpu img buffer
        for(int i = 0; i < 8; i++)  framesGPU[i].upload(cv::Mat::zeros(imgTmpUndistort.size(),imgTmpUndistort.type()));
        framesGPU[0].upload(imgTmpUndistort);
        framesGPU[1].upload(imgTmpUndistort);
        //init cpu img buffer
        for(int i = 0; i < 8; i++) framesCPU[i] = imgTmpUndistort.clone();
        framesCPU[0]   = imgTmpUndistort.clone();
        framesCPU[1]   = imgTmpUndistort.clone();

        img_previous    = framesCPU[0];
        d_img_previous  = framesGPU[0];
        img_undistort   = framesCPU[1];
        d_img_undistort = framesGPU[1];

        double copyGPUTimeRead = 0,
                copyGPUTime = 0,
                remapTime   = 0,
                grayConversionTime = 0,
                opticalFlowTime = 0,
                findHomographyTime = 0,
                filterMatrixTime = 0,
                smoothMatrixTime = 0,
                truncateTransformTime = 0,
                warpTime = 0,
                featuresTrackTime = 0;
                
        std::ofstream times;
        //times.open("times.txt", std::ios::out | std::ios::app);

        //
        // Run processing loop
        //
        int nFrame = 0;

        int lastFrameIdx         = 1;
        int previousLastFrameIdx = 0;
        //warm up
        //TODO: copy code
#define M(T,V,I) I;
        for(int i = 0; i < 50; i++){
            M(TM2, grayConversionTime,
#if CVT_COLOR==GPU
              cv::gpu::cvtColor(d_img_read, d_img_gray, CV_BGR2GRAY);
#elif CVT_COLOR==CPU
              cv::cvtColor(img_read, img_gray, CV_BGR2GRAY);
#endif
            );

            M(TM2, remapTime,
#if REMAP==GPU
  #if CVT_COLOR==CPU
              d_img_gray.upload(img_gray);
  #endif
              cv::gpu::remap(d_img_gray, d_img_undistort, mapX_gpu, mapY_gpu, CV_INTER_LINEAR);
#elif REMAP==CPU
  #if CVT_COLOR==GPU
              d_img_gray.download(img_gray);
  #endif
              cv::remap(img_gray, img_undistort, mapX, mapY, CV_INTER_LINEAR);
#endif
            );

            M(TM2, copyGPUTime,
#if REMAP==GPU
  #if FEATURES==CPU || OPTICAL_FLOW==CPU
              d_img_undistort.download(img_undistort);
  #endif
#elif REMAP==CPU
  #if FEATURES==GPU || OPTICAL_FLOW==GPU
              d_img_undistort.upload(img_undistort);
  #endif
#endif
            );

            M(TM2, featuresTrackTime,
              std::vector<cv::KeyPoint> tmpPoints;
#if FEATURES==CPU
              detector_cpu.detect(img_previous, tmpPoints);
              points.clear();
              for(std::vector<cv::KeyPoint>::iterator it = tmpPoints.begin(); it != tmpPoints.end(); it++)
              {
                  points.push_back(it->pt);
              }
#elif FEATURES==GPU
  #if FEATURES_TYPE==HARRIS
              detector_gpu(d_img_previous, dPoints);
  #elif FEATURES_TYPE==FAST
              detector_gpu (d_img_previous, cv::gpu::GpuMat(), tmpPoints);
              points.clear();
              for(std::vector<cv::KeyPoint>::iterator it = tmpPoints.begin(); it != tmpPoints.end(); it++)
              {
                  points.push_back(it->pt);
              }
  #endif
#endif
            );

            M(TM2, opticalFlowTime,
#if OPTICAL_FLOW==CPU
  #if FEATURES==GPU && FEATURES_TYPE==HARRIS
              download(dPoints, points);
  #endif
              std::swap(pyramid_cur, pyramid_old);
              cv::buildOpticalFlowPyramid(img_undistort, pyramid_cur, winSizeOfFlow, LK_MAX_LEVEL_PYRAMID, true);
              cv::calcOpticalFlowPyrLK(pyramid_old, pyramid_cur, points, points_est, status, error, winSizeOfFlow, LK_MAX_LEVEL_PYRAMID);
#elif OPTICAL_FLOW==GPU
  #if FEATURES==CPU || FEATURES_TYPE == FAST
              upload(dPoints, points);
  #endif
              d_pyrLK.sparse(d_img_previous, d_img_undistort, dPoints, dPointsEst, dStatus);
#endif
            );

            M(TM2, findHomographyTime,
              cv::Mat pointsFound;
#if OPTICAL_FLOW==GPU
  #if FEATURES==GPU && FEATURES_TYPE==HARRIS
              download(dPoints, points);
  #endif
            download(dPointsEst, points_est);

#endif
            if(points.size() == 0)
            {
                cv::Mat i;
                d_img_previous.download(i);
                cv::imshow("img", i);
                cv::waitKey(0);
            }
            cv::Mat h = cv::findHomography(points, points_est, CV_RANSAC, 3, pointsFound);
            );

            //filter homography
            M(TM2, filterMatrixTime,
              cv::Mat h2;
              h.convertTo(h2, CV_32F);

              int nInlier = 0;
              for (int i = 0; i < points.size(); i++)
              {
                if ((int)pointsFound.at<uchar>(i, 0) == 1)
                {
                    ++nInlier;
                }
              }

              h2 = filter(h2, nInlier, points.size(), img_undistort.size());
            );

            M(TM2, smoothMatrixTime,
              mats.push_back(h2.clone().t());mats.pop_front();
              cv::Mat t = smoothMatrix(mats);
            );

            M(TM2, truncateTransformTime,
              t = truncateTransform(t, img_undistort);
              t = t.t();
            );

            cv::Mat imgWarped;

            M(TM2, warpTime,
#if WARP==CPU
              cv::warpPerspective(framesCPU[(lastFrameIdx+1)&7], imgWarped, t, img_undistort.size(), cv::INTER_LINEAR | cv::WARP_INVERSE_MAP);
#elif WARP==GPU
              cv::gpu::warpPerspective(framesGPU[(lastFrameIdx+1)&7], dImgWarped, t, img_undistort.size(), cv::INTER_LINEAR | cv::WARP_INVERSE_MAP);
              dImgWarped.download(imgWarped);
#endif
            );
        }

        p.start();
        TM.start();

        reader.start();
        p.resumeCollection();

        uint64_t totalTimeExecution = 0;
        int totalFramesSkipped = 0;
        TM3.start();
        //#define M(T,V,I) T.start(); I; T.stop(); V+=T.duration();
        while (true)
        {
            M(TM2, grayConversionTime,
#if CVT_COLOR==GPU
              cv::gpu::cvtColor(d_img_read, d_img_gray, CV_BGR2GRAY);
#elif CVT_COLOR==CPU
              cv::cvtColor(img_read, img_gray, CV_BGR2GRAY);
#endif
            );

            M(TM2, remapTime,
#if REMAP==GPU
  #if CVT_COLOR==CPU
              d_img_gray.upload(img_gray);
  #endif
              cv::gpu::remap(d_img_gray, d_img_undistort, mapX_gpu, mapY_gpu, CV_INTER_LINEAR);
#elif REMAP==CPU
  #if CVT_COLOR==GPU
              d_img_gray.download(img_gray);
  #endif
              cv::remap(img_gray, img_undistort, mapX, mapY, CV_INTER_LINEAR);
#endif
            );

            M(TM2, copyGPUTime,
#if REMAP==GPU
  #if FEATURES==CPU || OPTICAL_FLOW==CPU
              d_img_undistort.download(img_undistort);
  #endif
#elif REMAP==CPU
  #if FEATURES==GPU || OPTICAL_FLOW==GPU
              d_img_undistort.upload(img_undistort);
  #endif
#endif
            );

            M(TM2, featuresTrackTime,
              std::vector<cv::KeyPoint> tmpPoints;
#if FEATURES==CPU
              detector_cpu.detect(img_previous, tmpPoints);
              points.clear();
              for(std::vector<cv::KeyPoint>::iterator it = tmpPoints.begin(); it != tmpPoints.end(); it++)
              {
                  points.push_back(it->pt);
              }
#elif FEATURES==GPU
  #if FEATURES_TYPE==HARRIS
              detector_gpu(d_img_previous, dPoints);
  #elif FEATURES_TYPE==FAST
              detector_gpu (d_img_previous, cv::gpu::GpuMat(), tmpPoints);
              points.clear();
              for(std::vector<cv::KeyPoint>::iterator it = tmpPoints.begin(); it != tmpPoints.end(); it++)
              {
                  points.push_back(it->pt);
              }
  #endif
#endif
            );

            M(TM2, opticalFlowTime,
#if OPTICAL_FLOW==CPU
  #if FEATURES==GPU && FEATURES_TYPE==HARRIS
              download(dPoints, points);
  #endif
              std::swap(pyramid_cur, pyramid_old);
              cv::buildOpticalFlowPyramid(img_undistort, pyramid_cur, winSizeOfFlow, LK_MAX_LEVEL_PYRAMID, true);
              cv::calcOpticalFlowPyrLK(pyramid_old, pyramid_cur, points, points_est, status, error, winSizeOfFlow, LK_MAX_LEVEL_PYRAMID);
#elif OPTICAL_FLOW==GPU
  #if FEATURES==CPU || FEATURES_TYPE == FAST
              upload(dPoints, points);
  #endif
              d_pyrLK.sparse(d_img_previous, d_img_undistort, dPoints, dPointsEst, dStatus);
#endif
            );

            M(TM2, findHomographyTime,
              cv::Mat pointsFound;
#if OPTICAL_FLOW==GPU
  #if FEATURES==GPU && FEATURES_TYPE==HARRIS
              download(dPoints, points);
  #endif
            download(dPointsEst, points_est);

#endif
            /*if(points.size() == 0)
            {
                cv::Mat i;
                d_img_previous.download(i);
                cv::imshow("img", i);
                cv::waitKey(0);
            }*/
            cv::Mat h = cv::findHomography(points, points_est, CV_RANSAC, 3, pointsFound);
            /*cv::Mat tmp = cv::estimateRigidTransform(points, points_est, false);
cv::Mat h(3,3, tmp.type());
h.at<double>(0,0) = tmp.at<double>(0,0);
h.at<double>(0,1) = tmp.at<double>(0,1);
h.at<double>(0,2) = tmp.at<double>(0,2);

h.at<double>(1,0) = tmp.at<double>(1,0);
h.at<double>(1,1) = tmp.at<double>(1,1);
h.at<double>(1,2) = tmp.at<double>(1,2);

h.at<double>(2,0) = 0.0;
h.at<double>(2,1) = 0.0;
h.at<double>(2,2) = 1.0;*/
            );

            //filter homography
            M(TM2, filterMatrixTime,
              cv::Mat h2;
              h.convertTo(h2, CV_32F);

              int nInlier = 0;
              for (int i = 0; i < points.size(); i++)
              {
                if ((int)pointsFound.at<uchar>(i, 0) == 1)
                {
                    ++nInlier;
                }
              }

              h2 = filter(h2, nInlier, points.size(), img_undistort.size());
            );

            M(TM2, smoothMatrixTime,
              mats.push_back(h2.clone().t());mats.pop_front();
              cv::Mat t = smoothMatrix(mats);
            );

            M(TM2, truncateTransformTime,
              t = truncateTransform(t, img_undistort);
              t = t.t();
            );

            cv::Mat imgWarped;

            M(TM2, warpTime,
#if WARP==CPU
              cv::warpPerspective(framesCPU[(lastFrameIdx+1)&7], imgWarped, t, img_undistort.size(), cv::INTER_LINEAR | cv::WARP_INVERSE_MAP);
#elif WARP==GPU
              cv::gpu::warpPerspective(framesGPU[(lastFrameIdx+1)&7], dImgWarped, t, img_undistort.size(), cv::INTER_LINEAR | cv::WARP_INVERSE_MAP);
              dImgWarped.download(imgWarped);
#endif
            );

            //p.pauseCollection();

            TM3.stop();
            totalTimeExecution += TM3.durationNano();
            //
            // Read frame
            //
            TM2.start();
            nFrame++;
reader.start();
            int framesSkipped = reader.read(img_read, &p);
            totalFramesSkipped += framesSkipped;
            if(framesSkipped < 0) break;
            d_img_read.upload(img_read);
            TM2.stop();
            tot_time_read += TM2.duration();
            
            if(times.is_open())
            {
              times << x << ";";
              times << (( READER        == OPENCV ) ? "OPENCV" : "OPENVX" ) << ";";
              times << (( CVT_COLOR     == CPU    ) ? "CPU"    : "GPU"    ) << ";";
              times << (( REMAP         == CPU    ) ? "CPU"    : "GPU"    ) << ";";
              times << (( FEATURES      == CPU    ) ? "CPU"    : "GPU"    ) << ";";
              times << (( FEATURES_TYPE == HARRIS ) ? "HARRIS" : "FAST"   ) << ";";
              times << (( OPTICAL_FLOW  == CPU    ) ? "CPU"    : "GPU"    ) << ";";
              times << (( WARP          == CPU    ) ? "CPU"    : "GPU"    ) << ";";
              times << TM3.durationNano() << ";";
              times << framesSkipped << ";";
              times << std::endl;
            }
            {
#define PATH "./disk/fsr2017"
#define WRITE(img, destination) { char bufferName[100]; sprintf(bufferName, "%s/%s/%05d.png", PATH, destination, nFrame); cv::imwrite(std::string(bufferName), img); }
				WRITE( img_read, "img/0_original" );
				d_img_gray.download(img_gray);
				WRITE( img_gray, "img/1_gray" );
				WRITE( img_undistort, "img/2_undistort" );
				WRITE( imgWarped, "img/3_stabilized" );
            }
            /*
            for(int i = 0; i < points.size(); i++)
            {
                cv::circle(img_previous, points[i], 10, cv::Scalar(255), 2);
            }
            cv::Point2f pp(10,10);
            for(int i = 0; i < points.size(); i++)
            {
                cv::rectangle(img_previous, points_est[i]-pp, points_est[i]+pp, cv::Scalar(0), 2);
            }
            d_img_previous.upload(img_previous);

            cv::imshow("img", imgWarped);
            cv::waitKey(1000/30);
            //*/

            img_previous   = framesCPU[lastFrameIdx];
            d_img_previous = framesGPU[lastFrameIdx];

            previousLastFrameIdx = lastFrameIdx;
            lastFrameIdx = (lastFrameIdx+1) & 7;

            img_undistort   = framesCPU[lastFrameIdx];
            d_img_undistort = framesGPU[lastFrameIdx];


            TM3.start();

            p.resumeCollection();
            reader.start();
        }

        TM.stop();
        p.stop();
        std::cout << totalTimeExecution / 1000000000.0 << " s execution time" << std::endl;
        
        std::cout << "N frame processed: " << nFrame << std::endl;
        std::cout << "Avg time : " << TM.duration() / nFrame << "ms" << std::endl;
        std::cout << "Proc. time outside measure: " << TM.duration() - tot_time_read - ( copyGPUTimeRead + copyGPUTime + grayConversionTime + opticalFlowTime + findHomographyTime + filterMatrixTime + smoothMatrixTime + truncateTransformTime + warpTime + featuresTrackTime ) << " ms " << std::endl;
        std::cout << "Avg time read: " << tot_time_read / nFrame << "ms" << std::endl;
        std::cout << "Avg time summed: " << ( copyGPUTimeRead + copyGPUTime + grayConversionTime + opticalFlowTime + findHomographyTime + filterMatrixTime + smoothMatrixTime + truncateTransformTime + warpTime + featuresTrackTime ) / nFrame << "ms" << std::endl;
        std::cout << "\tAvg Copy GPU : " << (copyGPUTime+copyGPUTimeRead) / nFrame << "ms" << std::endl;
        std::cout << "\tAvg Gray : " << grayConversionTime / nFrame << "ms" << std::endl;
        std::cout << "\tAvg Opt flow : " << opticalFlowTime / nFrame << "ms" << std::endl;
        std::cout << "\tAvg find homography : " << findHomographyTime / nFrame << "ms" << std::endl;
        std::cout << "\tAvg filter matrix : " << filterMatrixTime / nFrame << "ms" << std::endl;
        std::cout << "\tAvg smooth matrix : " << smoothMatrixTime / nFrame << "ms" << std::endl;
        std::cout << "\tAvg Truncate transform : " << truncateTransformTime / nFrame << "ms" << std::endl;
        std::cout << "\tAvg Warp Time : " << warpTime / nFrame << "ms" << std::endl;
        std::cout << "\tAvg Features Time : " << featuresTrackTime / nFrame << "ms" << std::endl;

        std::cout << "Tot time read: " << tot_time_read / 1000 << "s" << std::endl;
        std::cout << "Power avg: " << p.getPowerAvg() << std::endl;
        std::cout << "Power max: " << p.getPowerMax() << std::endl;
        std::cout << "Power total: " << p.getPowerTotal() << std::endl;
        std::cout << "Sampled instants: " << p.getSampledInstants() << std::endl;
        std::cout << "Timer dur: " << TM.duration() << std::endl;
        std::cout << "Tot energy: " << (TM.duration())*p.getPowerAvg()/1000 << std::endl;
        
        
        bool writeHeader = false;
        {
        	std::ifstream input("results.txt");
        	writeHeader = !input.good();
        }
        std::ofstream output;
        output.open("results.txt", std::ios::out | std::ios::app);
        if(output.is_open())
        {
        	if(writeHeader)
					{
						output << "Filename;";
						output << "Number of try;";
						output << "Reader;";
						output << "Convert color;";
						output << "Remap;";
						output << "Features;";
						output << "Features type;";
						output << "Optical flow;";
						output << "Warp;";
						output << "Total frames processed;";
						output << "Total time executed (ns);";
						output << "Power avg;";
						output << "Power max;";
						output << "Power total;";
						output << "Sampled instants;";
						output << "Frames to skip;";
						output << "TotalFrames skipped;";
						output << std::endl;
					}
          output << videoFilePath << ";";
          output << x << ";";
          output << (( READER        == OPENCV ) ? "OPENCV" : "OPENVX" ) << ";";
          output << (( CVT_COLOR     == CPU    ) ? "CPU"    : "GPU"    ) << ";";
          output << (( REMAP         == CPU    ) ? "CPU"    : "GPU"    ) << ";";
          output << (( FEATURES      == CPU    ) ? "CPU"    : "GPU"    ) << ";";
          output << (( FEATURES_TYPE == HARRIS ) ? "HARRIS" : "FAST"   ) << ";";
          output << (( OPTICAL_FLOW  == CPU    ) ? "CPU"    : "GPU"    ) << ";";
          output << (( WARP          == CPU    ) ? "CPU"    : "GPU"    ) << ";";
          output << nFrame << ";";
          output << totalTimeExecution << ";";
          output << p.getPowerAvg() << ";";
          output << p.getPowerMax() << ";";
          output << p.getPowerTotal() << ";";
          output << p.getSampledInstants() << ";";
          output << framesToSkip << ";";
          output << totalFramesSkipped << ";";
          output << std::endl;
        }
        output.close();
//        times.close();
    }
    catch (const std::exception& e)
    {
        std::cerr << "Error: " << e.what() << std::endl;
        return nvxio::Application::APP_EXIT_CODE_ERROR;
    }

    return nvxio::Application::APP_EXIT_CODE_SUCCESS;
}
