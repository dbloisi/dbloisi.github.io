#!/bin/bash
#nvcc -O3 -std=c++11 mainClean.cpp -lopencv_core -lopencv_imgproc -lopencv_calib3d -lopencv_video -lopencv_features2d -lopencv_highgui initFrames.cpp powermon.cpp Timer.cpp -o videoOpenCV.x

#nvcc -O3 -std=c++11 mainClean.cpp powermon.cpp Timer.cpp -lopencv_core -lopencv_imgproc -lopencv_calib3d -lopencv_video -lopencv_features2d -lopencv_highgui -lopencv_gpu -o videoOpenCV.x
g++ -O3 -pthread -std=c++11 mainClean.cpp powermon.cpp Timer.cpp -lopencv_core -lopencv_imgproc -lopencv_calib3d -lopencv_video -lopencv_features2d -lopencv_highgui -lopencv_gpu -lnvxio -lvisionworks -o videoOpenCV.x
